Shia Namaz, fully offline Android app (by Javed Iqbal)
======================================================
Upload this zip to a PRIVATE GitHub repository WITHOUT unzipping it.
GitHub then builds ShiaNamaz.apk for you. See the steps in the chat.

This zip contains your app's signing key (release.jks). Keep the
repository private and keep a copy of this zip safe. Every future
update must be built with this same key so it installs over the old app.

build.yml is a copy of the workflow file you paste into
.github/workflows/build.yml on GitHub.

package com.javediqbal.shianamaz;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Small widget: the next prayer, its time and a live countdown. */
public class NextPrayerWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        WidgetUtil.updateAll(context);
    }
}

package com.javediqbal.shianamaz;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;

/** Receives the alert alarm (and the Stop / Prayed buttons), starts the sound, and sets the next alert. */
public class AlertReceiver extends BroadcastReceiver {
    static final String ALERT = "com.javediqbal.shianamaz.ALERT", TEST = "com.javediqbal.shianamaz.TEST",
        STOP = "com.javediqbal.shianamaz.STOP", PRAYED = "com.javediqbal.shianamaz.PRAYED";

    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null) return;
        if (ALERT.equals(a) || TEST.equals(a)) {
            Intent s = new Intent(c, AlertService.class).setAction(AlertService.PLAY).putExtras(in).putExtra("kind", a);
            boolean started = false;
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
                started = true;
            } catch (Exception ignored) { }
            if (!started) AlertService.notifyOnly(c, in);   // the phone refused the player: a normal notification with sound instead
            if (ALERT.equals(a)) PrayerAlarm.schedule(c);     // set the next alert straight away
        } else if (STOP.equals(a)) {
            AlertService.stopNow();
        } else if (PRAYED.equals(a)) {
            try {
                String key = PrayerCalc.KEYS[in.getIntExtra("key", 0)];
                String day = in.getIntExtra("y", 0) + "-" + in.getIntExtra("m", 0) + "-" + in.getIntExtra("d", 0);
                JSONArray q = new JSONArray(PrayerAlarm.prefs(c).getString("prayed", "[]"));
                q.put(key + "|" + day);
                PrayerAlarm.prefs(c).edit().putString("prayed", q.toString()).apply();
            } catch (Exception ignored) { }
            AlertService.stopNow();
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(AlertService.NID);
        }
    }
}

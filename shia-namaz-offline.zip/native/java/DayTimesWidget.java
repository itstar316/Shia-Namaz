package com.javediqbal.shianamaz;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** Wide widget: all of today's prayer times with the next one highlighted. */
public class DayTimesWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        WidgetUtil.updateAll(context);
    }

    /** Called when the widget is resized: redraw it for its new size. */
    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        WidgetUtil.updateAll(context);
    }
}

package com.javediqbal.shianamaz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.TimeZone;

/** Builds and refreshes the home-screen widgets. Settings arrive from the app through AppBridgePlugin. */
public final class WidgetUtil {
    private WidgetUtil() {}

    static final String PREFS = "shianamaz_widget";
    static final String ACTION_TICK = "com.javediqbal.shianamaz.WIDGET_TICK";
    static final String[] EN = {"Imsak", "Fajr", "Sunrise", "Zuhr", "Asr", "Sunset", "Maghrib", "Isha", "Midnight"};
    static final String[] UR = {"امساک", "فجر", "طلوعِ آفتاب", "ظہر", "عصر", "غروبِ آفتاب", "مغرب", "عشاء", "نصف شب"};
    static final int[] ALERT = {PrayerCalc.IMSAK, PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final int[] DAY_CELLS = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final String[] WD = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static final String[] WD_UR = {"اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"};
    static final String[] MO_UR = {"جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"};
    static final String[] MO = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final int WHITE = Color.WHITE, SOFT = 0xD9FFFFFF, GOLD = 0xFFF2C26B;

    static final class Cfg {
        double lat = 24.8607, lng = 67.0011;
        String name = "Karachi", method = "qum", lang = "ur", ramadan = "auto";
        boolean h24 = false;
        int hijri = -1, glass = 1;
        int[] offsets = new int[9];
        String[] months = {"Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Awwal", "Jumada al-Thani",
            "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul Qadah", "Dhul Hijjah"};
    }

    static final class State {
        int[] today;
        int now, next, nextMin, hl;
        long nextUtc, refreshAt;
        boolean ram;
        int[] tm;
        String hijri;
    }

    static Cfg load(Context c) {
        Cfg k = new Cfg();
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("cfg", null);
            if (s == null) return k;
            JSONObject o = new JSONObject(s);
            k.lat = o.optDouble("lat", k.lat);
            k.lng = o.optDouble("lng", k.lng);
            k.name = o.optString("name", k.name);
            k.method = o.optString("method", k.method);
            k.lang = o.optString("lang", k.lang);
            k.ramadan = o.optString("ramadan", k.ramadan);
            k.h24 = o.optBoolean("h24", false);
            k.hijri = o.optInt("hijri", -1);
            k.glass = o.optInt("glass", 1);
            JSONObject off = o.optJSONObject("offsets");
            if (off != null) for (int i = 0; i < 9; i++) k.offsets[i] = off.optInt(PrayerCalc.KEYS[i], 0);
            JSONArray ms = o.optJSONArray("months");
            if (ms != null && ms.length() == 12) for (int i = 0; i < 12; i++) k.months[i] = ms.optString(i, k.months[i]);
        } catch (Exception ignored) { }
        return k;
    }

    static State state(Cfg k, long nowMs) {
        State st = new State();
        int[] p = PrayerCalc.pktNow(nowMs);
        st.today = new int[]{p[0], p[1], p[2]};
        st.now = p[3];
        st.tm = PrayerCalc.schedule(st.today, k.lat, k.lng, k.method, k.offsets);
        int[] nx = PrayerCalc.schedule(PrayerCalc.addDays(st.today, 1), k.lat, k.lng, k.method, k.offsets);
        // Imsak is not a prayer: it only counts on Ramadan days, as the end of Sehri
        boolean ramToday = isRamDay(k, st.today), ramTomorrow = isRamDay(k, PrayerCalc.addDays(st.today, 1));
        st.next = -1;
        for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramToday) continue;
            if (st.tm[i] > st.now && (st.next < 0 || st.tm[i] < st.nextMin)) { st.next = i; st.nextMin = st.tm[i]; }
        }
        if (st.next < 0) for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramTomorrow) continue;
            if (st.next < 0 || nx[i] + 1440 < st.nextMin) { st.next = i; st.nextMin = nx[i] + 1440; }
        }
        st.nextUtc = PrayerCalc.utcMs(st.today, st.nextMin);
        st.hl = st.next == PrayerCalc.IMSAK ? PrayerCalc.FAJR : st.next;
        boolean night = st.now >= st.tm[PrayerCalc.MAGHRIB];
        int[] h = PrayerCalc.hijri(night ? PrayerCalc.addDays(st.today, 1) : st.today, k.hijri);
        String mon = k.months[Math.max(0, Math.min(11, h[1] - 1))];
        boolean ur = !"en".equals(k.lang);
        st.hijri = night ? (ur ? "شبِ " + h[0] + " " + mon : "Night of " + h[0] + " " + mon) : h[0] + " " + mon + " " + h[2];
        st.ram = "on".equals(k.ramadan) || (!"off".equals(k.ramadan) && h[1] == 9);
        long midnight = PrayerCalc.utcMs(st.today, 1440);
        long maghrib = PrayerCalc.utcMs(st.today, st.tm[PrayerCalc.MAGHRIB]);
        long at = Math.min(st.nextUtc, midnight);
        if (maghrib > nowMs) at = Math.min(at, maghrib);
        st.refreshAt = Math.max(at, nowMs + 30000L) + 2000L;
        return st;
    }

    static boolean urdu(Cfg k) { return !"en".equals(k.lang); }

    /** prayer label in the chosen language; in Ramadan, Imsak and Maghrib read as Sehri and Iftar */
    static String label(int key, Cfg k, boolean ram, boolean other) {
        boolean ur = urdu(k) != other;
        if (ram && key == PrayerCalc.IMSAK) return ur ? "سحری کا اختتام" : "Sehri ends";
        if (ram && key == PrayerCalc.MAGHRIB) return ur ? "افطار" : "Iftar";
        return ur ? UR[key] : EN[key];
    }

    static String period(int h, boolean ur) {
        if (!ur) return h >= 12 ? "pm" : "am";
        if (h >= 4 && h < 12) return "صبح";
        if (h >= 12 && h < 16) return "دوپہر";
        if (h >= 16 && h < 19) return "شام";
        return "رات";
    }

    static boolean isRamDay(Cfg k, int[] ymd) {
        if ("on".equals(k.ramadan)) return true;
        if ("off".equals(k.ramadan)) return false;
        return PrayerCalc.hijri(ymd, k.hijri)[1] == 9;
    }

    static String[] fmt(int min, boolean h24) { return fmt(min, h24, false); }

    static String[] fmt(int min, boolean h24, boolean ur) {
        int m = ((min % 1440) + 1440) % 1440, h = m / 60, mm = m % 60;
        String two = (mm < 10 ? "0" : "") + mm;
        if (h24) return new String[]{(h < 10 ? "0" : "") + h + ":" + two, ""};
        String ap = period(h, ur);
        h = h % 12;
        if (h == 0) h = 12;
        return new String[]{h + ":" + two, ap};
    }

    static int glassRes(int g) {
        switch (g) {
            case 0: return R.drawable.wg_glass0;
            case 2: return R.drawable.wg_glass2;
            case 3: return R.drawable.wg_glass3;
            default: return R.drawable.wg_glass1;
        }
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent openApp(Context ctx) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (i == null) i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 0, i, piFlags());
    }

    static void countdown(RemoteViews v, int id, long target, long nowMs, boolean ur) {
        if (Build.VERSION.SDK_INT >= 24) {
            long base = SystemClock.elapsedRealtime() + Math.max(0L, target - nowMs);
            v.setChronometer(id, base, ur ? "%s باقی" : "in %s", true);
            v.setChronometerCountDown(id, true);
            v.setViewVisibility(id, View.VISIBLE);
        } else {
            v.setViewVisibility(id, View.GONE);
        }
    }

    static RemoteViews buildNext(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_next);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, st.hijri);
        v.setTextViewText(R.id.w_name, label(st.next, k, st.ram, false));
        v.setTextViewText(R.id.w_ur, label(st.next, k, st.ram, true));
        String[] t = fmt(st.nextMin, k.h24, urdu(k));
        v.setTextViewText(R.id.w_time, t[0]);
        v.setTextViewText(R.id.w_ampm, t[1]);
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, urdu(k));
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static final int[] CELL = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5};
    static final int[] NAME = {R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5};
    static final int[] TIME = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5};

    static RemoteViews buildDay(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_day);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(st.today[0], st.today[1] - 1, st.today[2]);
        boolean ur = urdu(k);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        String date = ur ? WD_UR[dow] + "، " + st.today[2] + " " + MO_UR[st.today[1] - 1]
                         : WD[dow] + ", " + st.today[2] + " " + MO[st.today[1] - 1];
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, date + "  \u2022  " + st.hijri);
        v.setTextViewText(R.id.w_next, label(st.next, k, st.ram, false) + " " + join(fmt(st.nextMin, k.h24, ur)));
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, ur);
        for (int i = 0; i < 6; i++) {
            int key = DAY_CELLS[i];
            boolean on = key == st.hl;
            v.setTextViewText(NAME[i], label(key, k, st.ram, false));
            v.setTextViewText(TIME[i], fmt(st.tm[key], k.h24)[0]);
            v.setTextColor(NAME[i], on ? GOLD : SOFT);
            v.setTextColor(TIME[i], on ? GOLD : WHITE);
            v.setInt(CELL[i], "setBackgroundResource", on ? R.drawable.wg_cell_on : R.drawable.wg_cell_off);
        }
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    // ---------- Daily saying ----------
    private static JSONArray quotes;

    static JSONArray quotes(Context ctx) {
        if (quotes != null) return quotes;
        try {
            InputStream in = ctx.getAssets().open("quotes.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            quotes = new JSONArray(new String(out.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            quotes = new JSONArray();
        }
        return quotes;
    }

    /** Same rule as the app: days since 1 Jan 2026 (Pakistan date), wrapped around the list. */
    static JSONArray quoteToday(Context ctx, int[] today) {
        JSONArray all = quotes(ctx);
        int n = all.length();
        if (n == 0) return null;
        long diff = PrayerCalc.utcMs(today, 0) - PrayerCalc.utcMs(new int[]{2026, 1, 1}, 0);
        long days = diff >= 0 ? diff / 86400000L : -((-diff + 86399999L) / 86400000L);
        int i = (int) (((days % n) + n) % n);
        return all.optJSONArray(i);
    }

    static RemoteViews buildQuote(Context ctx, Cfg k, State st) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_quote);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        boolean ur = urdu(k);
        JSONArray q = quoteToday(ctx, st.today);
        if (q != null) {
            int num = q.optInt(0, 0);
            v.setTextViewText(R.id.q_text, q.optString(ur ? 2 : 1, ""));
            v.setTextViewText(R.id.q_ref, ur ? "امام علیؑ، نہج البلاغہ، حکمت " + num : "Imam Ali (as), Nahj al-Balagha, Saying " + num);
        }
        v.setTextViewText(R.id.q_title, ur ? "آج کا قول" : "Saying of the day");
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static String join(String[] t) { return t[1].isEmpty() ? t[0] : t[0] + " " + t[1]; }

    /** Redraw every placed widget and schedule the next redraw at the next prayer, Maghrib or midnight. */
    public static void updateAll(Context ctx) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] a = m.getAppWidgetIds(new ComponentName(ctx, NextPrayerWidget.class));
            int[] b = m.getAppWidgetIds(new ComponentName(ctx, DayTimesWidget.class));
            int[] q = m.getAppWidgetIds(new ComponentName(ctx, QuoteWidget.class));
            if (a.length == 0 && b.length == 0 && q.length == 0) return;
            Cfg k = load(ctx);
            long now = System.currentTimeMillis();
            State st = state(k, now);
            if (a.length > 0) m.updateAppWidget(a, buildNext(ctx, k, st, now));
            if (b.length > 0) m.updateAppWidget(b, buildDay(ctx, k, st, now));
            if (q.length > 0) m.updateAppWidget(q, buildQuote(ctx, k, st));
            scheduleTick(ctx, st.refreshAt);
        } catch (Exception ignored) { }
    }

    static void scheduleTick(Context ctx, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, WidgetRefreshReceiver.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7, i, piFlags());
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}

package com.javediqbal.shianamaz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.TimeZone;

/** Builds and refreshes the home-screen widgets. Settings arrive from the app through AppBridgePlugin. */
public final class WidgetUtil {
    private WidgetUtil() {}

    static final String PREFS = "shianamaz_widget";
    static final String ACTION_TICK = "com.javediqbal.shianamaz.WIDGET_TICK";
    static final String[] EN = {"Imsak", "Fajr", "Sunrise", "Zuhr", "Asr", "Sunset", "Maghrib", "Isha", "Midnight"};
    static final String[] UR = {"امساک", "فجر", "طلوعِ آفتاب", "ظہر", "عصر", "غروبِ آفتاب", "مغرب", "عشاء", "نصف شب"};
    static final int[] ALERT = {PrayerCalc.IMSAK, PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final int[] DAY_CELLS = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final String[] WD = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static final String[] WD_UR = {"اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"};
    static final String[] MO_UR = {"جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"};
    static final String[] MO = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final int WHITE = Color.WHITE, SOFT = 0xD9FFFFFF, GOLD = 0xFFF2C26B;

    static final class Cfg {
        double lat = 24.8607, lng = 67.0011;
        String name = "Karachi", method = "qum", lang = "ur", ramadan = "auto", tz = "Asia/Karachi";
        boolean h24 = false;
        int hijri = -1, glass = 1;
        int[] offsets = new int[9];
        String[] months = {"Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Awwal", "Jumada al-Thani",
            "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul Qadah", "Dhul Hijjah"};
    }

    static final class State {
        int[] today;
        int now, next, nextMin, hl;
        long nextUtc, refreshAt;
        boolean ram;
        int[] tm;
        String hijri;
        int hm, hd;
        boolean ramCard;  // Ramadan: the widgets show Sehri ends / Iftar, like the app's Ramadan card
        int ramDay;       // day of Ramadan (0 when Ramadan mode is forced on outside Ramadan)
        String mood;      // null, "ashura", "aza", "sad", "joy" or "eid"
        String event;     // banner text for the day, or null
    }

    static Cfg load(Context c) {
        Cfg k = new Cfg();
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("cfg", null);
            if (s == null) return k;
            JSONObject o = new JSONObject(s);
            k.lat = o.optDouble("lat", k.lat);
            k.lng = o.optDouble("lng", k.lng);
            k.name = o.optString("name", k.name);
            k.method = o.optString("method", k.method);
            k.lang = o.optString("lang", k.lang);
            k.ramadan = o.optString("ramadan", k.ramadan);
            k.tz = o.optString("tz", k.tz);
            k.h24 = o.optBoolean("h24", false);
            k.hijri = o.optInt("hijri", -1);
            k.glass = o.optInt("glass", 1);
            JSONObject off = o.optJSONObject("offsets");
            if (off != null) for (int i = 0; i < 9; i++) k.offsets[i] = off.optInt(PrayerCalc.KEYS[i], 0);
            JSONArray ms = o.optJSONArray("months");
            if (ms != null && ms.length() == 12) for (int i = 0; i < 12; i++) k.months[i] = ms.optString(i, k.months[i]);
        } catch (Exception ignored) { }
        return k;
    }

    static State state(Cfg k, long nowMs) {
        State st = new State();
        int[] p = PrayerCalc.pktNow(nowMs, k.tz);
        st.today = new int[]{p[0], p[1], p[2]};
        st.now = p[3];
        st.tm = PrayerCalc.schedule(st.today, k.lat, k.lng, k.method, k.offsets, k.tz);
        int[] nx = PrayerCalc.schedule(PrayerCalc.addDays(st.today, 1), k.lat, k.lng, k.method, k.offsets, k.tz);
        // Imsak is not a prayer: it only counts on Ramadan days, as the end of Sehri
        boolean ramToday = isRamDay(k, st.today), ramTomorrow = isRamDay(k, PrayerCalc.addDays(st.today, 1));
        st.next = -1;
        for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramToday) continue;
            if (st.tm[i] > st.now && (st.next < 0 || st.tm[i] < st.nextMin)) { st.next = i; st.nextMin = st.tm[i]; }
        }
        if (st.next < 0) for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramTomorrow) continue;
            if (st.next < 0 || nx[i] + 1440 < st.nextMin) { st.next = i; st.nextMin = nx[i] + 1440; }
        }
        st.nextUtc = PrayerCalc.utcMs(st.today, st.nextMin, k.tz);
        st.hl = st.next == PrayerCalc.IMSAK ? PrayerCalc.FAJR : st.next;
        boolean night = st.now >= st.tm[PrayerCalc.MAGHRIB];
        int[] h = PrayerCalc.hijri(night ? PrayerCalc.addDays(st.today, 1) : st.today, k.hijri);
        st.hd = h[0]; st.hm = h[1];
        String mon = k.months[Math.max(0, Math.min(11, h[1] - 1))];
        boolean ur = !"en".equals(k.lang);
        st.hijri = night ? (ur ? "شبِ " + h[0] + " " + mon : "Night of " + h[0] + " " + mon) : h[0] + " " + mon + " " + h[2];
        st.ram = "on".equals(k.ramadan) || (!"off".equals(k.ramadan) && h[1] == 9);
        // Ramadan, exactly as the app's card: before Iftar the fast of today, after Iftar the fast of tomorrow;
        // until Sehri ends the target is Sehri's end, then Iftar
        if (!"off".equals(k.ramadan)) {
            boolean before = st.now < st.tm[PrayerCalc.MAGHRIB];
            int[] fastDate = before ? st.today : PrayerCalc.addDays(st.today, 1);
            int[] fh = PrayerCalc.hijri(fastDate, k.hijri);
            if (fh[1] == 9 || "on".equals(k.ramadan)) {
                int[] sch = before ? st.tm : nx;
                int base = before ? 0 : 1440;
                int imsak = sch[PrayerCalc.IMSAK] + base, iftar = sch[PrayerCalc.MAGHRIB] + base;
                boolean sehri = st.now < imsak;
                st.ramCard = true;
                st.ram = true;
                st.ramDay = fh[1] == 9 ? fh[0] : 0;
                st.next = sehri ? PrayerCalc.IMSAK : PrayerCalc.MAGHRIB;
                st.nextMin = sehri ? imsak : iftar;
                st.nextUtc = PrayerCalc.utcMs(st.today, st.nextMin, k.tz);
                st.hl = sehri ? PrayerCalc.FAJR : PrayerCalc.MAGHRIB;
            }
        }
        long midnight = PrayerCalc.utcMs(st.today, 1440, k.tz);
        long maghrib = PrayerCalc.utcMs(st.today, st.tm[PrayerCalc.MAGHRIB], k.tz);
        long at = Math.min(st.nextUtc, midnight);
        if (maghrib > nowMs) at = Math.min(at, maghrib);
        st.refreshAt = Math.max(at, nowMs + 30000L) + 2000L;
        return st;
    }

    static boolean urdu(Cfg k) { return !"en".equals(k.lang); }

    /** prayer label in the chosen language; in Ramadan, Imsak and Maghrib read as Sehri and Iftar */
    static String label(int key, Cfg k, boolean ram, boolean other) {
        boolean ur = urdu(k) != other;
        if (ram && key == PrayerCalc.IMSAK) return ur ? "سحری کا اختتام" : "Sehri ends";
        if (ram && key == PrayerCalc.MAGHRIB) return ur ? "افطار" : "Iftar";
        return ur ? UR[key] : EN[key];
    }

    static String period(int h, boolean ur) {
        if (!ur) return h >= 12 ? "pm" : "am";
        if (h >= 4 && h < 12) return "صبح";
        if (h >= 12 && h < 16) return "دوپہر";
        if (h >= 16 && h < 19) return "شام";
        return "رات";
    }

    static boolean isRamDay(Cfg k, int[] ymd) {
        if ("on".equals(k.ramadan)) return true;
        if ("off".equals(k.ramadan)) return false;
        return PrayerCalc.hijri(ymd, k.hijri)[1] == 9;
    }

    static String[] fmt(int min, boolean h24) { return fmt(min, h24, false); }

    static String[] fmt(int min, boolean h24, boolean ur) {
        int m = ((min % 1440) + 1440) % 1440, h = m / 60, mm = m % 60;
        String two = (mm < 10 ? "0" : "") + mm;
        if (h24) return new String[]{(h < 10 ? "0" : "") + h + ":" + two, ""};
        String ap = period(h, ur);
        h = h % 12;
        if (h == 0) h = 12;
        return new String[]{h + ":" + two, ap};
    }

    static int glassRes(int g) {
        switch (g) {
            case 0: return R.drawable.wg_glass0;
            case 2: return R.drawable.wg_glass2;
            case 3: return R.drawable.wg_glass3;
            default: return R.drawable.wg_glass1;
        }
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent openApp(Context ctx) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (i == null) i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 0, i, piFlags());
    }

    static void countdown(RemoteViews v, int id, long target, long nowMs, boolean ur) {
        if (Build.VERSION.SDK_INT >= 24) {
            long base = SystemClock.elapsedRealtime() + Math.max(0L, target - nowMs);
            v.setChronometer(id, base, ur ? "%s باقی" : "in %s", true);
            v.setChronometerCountDown(id, true);
            v.setViewVisibility(id, View.VISIBLE);
        } else {
            v.setViewVisibility(id, View.GONE);
        }
    }


    // ---------- Mood of the day (same rules as the app's sky) ----------
    private static JSONArray events;
    static final int[][] SAD_DAYS = {{1, 7}, {1, 9}, {1, 12}, {2, 20}, {7, 15}, {9, 19}, {10, 8}, {12, 9}};

    static JSONArray events(Context ctx) {
        if (events != null) return events;
        try {
            InputStream in = ctx.getAssets().open("events.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            events = new JSONArray(new String(out.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            events = new JSONArray();
        }
        return events;
    }

    /** sets st.mood and st.event from the Hijri date */
    static void mood(Context ctx, Cfg k, State st) {
        int m = st.hm, d = st.hd;
        JSONArray ev = null;
        JSONArray all = events(ctx);
        for (int i = 0; i < all.length(); i++) {
            JSONArray e = all.optJSONArray(i);
            if (e != null && e.optInt(0) == m && e.optInt(1) == d) { ev = e; break; }
        }
        boolean aza = m == 1 || m == 2 || (m == 3 && d <= 8);
        String type = ev == null ? "" : ev.optString(2);
        boolean sad = "shahadat".equals(type);
        for (int[] x : SAD_DAYS) if (x[0] == m && x[1] == d) sad = true;
        boolean ur = urdu(k);
        String title = ev == null ? null : ev.optString(ur ? 4 : 3);
        if (m == 1 && d <= 13) st.mood = "ashura";
        else if ("eid".equals(type)) st.mood = "eid";
        else if (sad) st.mood = "aza";   // every shahadat/wafat day: the same red mourning look as Muharram
        else if (aza) st.mood = "aza";
        else if ("wiladat".equals(type)) st.mood = "joy";
        else if (m == 9) st.mood = "ramadan";
        else st.mood = null;
        st.event = title;
        if (st.mood == null) { st.event = null; return; }
        boolean hasM = title != null && (title.contains("مبارک") || title.toLowerCase().contains("mubarak"));
        if ("eid".equals(st.mood)) {
            boolean isEid = ev != null && (ev.optString(3).toLowerCase().contains("eid") || ev.optString(4).contains("عید"));
            String wish = isEid ? (ur ? "عید مبارک" : "Eid Mubarak") : (ur ? "مبارک ہو" : "Mubarak");
            st.event = "\u2728 " + (hasM ? title : wish + (title != null ? " \u00b7 " + title : ""));
        } else if ("joy".equals(st.mood)) {
            st.event = "\u2728 " + (hasM ? title : (ur ? "مبارک ہو" : "Mubarak") + (title != null ? " \u00b7 " + title : ""));
        } else if (title == null && "aza".equals(st.mood)) {
            st.event = ur ? "ایامِ عزا" : "Ayyam-e-Aza";
        } else if ("ramadan".equals(st.mood)) {
            st.event = "\uD83C\uDF19 " + (title != null ? title : (ur ? "رمضان المبارک" : "Ramadan Kareem"));
        }
    }

    static int accent(State st) {
        if (st.mood == null) return GOLD;
        switch (st.mood) {
            case "ashura": case "aza": return 0xFFE88A8A;
            case "sad": return 0xFFD7CFE3;
            case "eid": return 0xFFF7D27A;
            case "ramadan": return 0xFFE8C77A;
            default: return GOLD;
        }
    }

    static int bgRes(Cfg k, State st) {
        if (k.glass == 0 || st.mood == null) return glassRes(k.glass);
        String m = st.mood.equals("ashura") ? "aza" : st.mood;
        int g = Math.max(1, Math.min(3, k.glass));
        switch (m + g) {
            case "aza1": return R.drawable.wg_aza1; case "aza2": return R.drawable.wg_aza2; case "aza3": return R.drawable.wg_aza3;
            case "sad1": return R.drawable.wg_sad1; case "sad2": return R.drawable.wg_sad2; case "sad3": return R.drawable.wg_sad3;
            case "joy1": return R.drawable.wg_joy1; case "joy2": return R.drawable.wg_joy2; case "joy3": return R.drawable.wg_joy3;
            case "eid1": return R.drawable.wg_eid1; case "eid2": return R.drawable.wg_eid2; case "eid3": return R.drawable.wg_eid3;
            case "ramadan1": return R.drawable.wg_ram1; case "ramadan2": return R.drawable.wg_ram2; case "ramadan3": return R.drawable.wg_ram3;
            default: return glassRes(k.glass);
        }
    }

    static int cellOn(State st) {
        if (st.mood == null) return R.drawable.wg_cell_on;
        switch (st.mood) {
            case "ashura": case "aza": return R.drawable.wg_cell_on_aza;
            case "sad": return R.drawable.wg_cell_on_sad;
            case "eid": return R.drawable.wg_cell_on_eid;
            case "ramadan": return R.drawable.wg_cell_on_ram;
            default: return R.drawable.wg_cell_on_joy;
        }
    }

    static void eventLine(RemoteViews v, State st) {
        if (st.event == null) { v.setViewVisibility(R.id.w_event, View.GONE); return; }
        v.setTextViewText(R.id.w_event, st.event);
        v.setTextColor(R.id.w_event, accent(st));
        v.setViewVisibility(R.id.w_event, View.VISIBLE);
    }

    /** "Maghrib  مغرب": the other language a little smaller and softer, in one line that auto-sizes as a whole */
    static CharSequence twoNames(String main, String other) {
        if (other == null || other.isEmpty() || other.equals(main)) return main;
        SpannableString s = new SpannableString(main + "  " + other);
        int a = main.length() + 2;
        s.setSpan(new RelativeSizeSpan(0.7f), a, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new ForegroundColorSpan(SOFT), a, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return s;
    }

    /** "12:18 pm" with a small am/pm */
    /** "→ 12:16 pm" (← in Urdu): a small arrow shows this is the next prayer's time, not the current time */
    static CharSequence timeText(String[] t, boolean ur) { return timeText(t, ur, true); }

    static CharSequence timeText(String[] t, boolean ur, boolean withArrow) {
        String arrow = withArrow ? (ur ? "\u2190 " : "\u2192 ") : "";
        String full = arrow + t[0] + (t[1].isEmpty() ? "" : " " + t[1]);
        SpannableString s = new SpannableString(full);
        s.setSpan(new RelativeSizeSpan(0.5f), 0, arrow.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new ForegroundColorSpan(SOFT), 0, arrow.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (!t[1].isEmpty()) s.setSpan(new RelativeSizeSpan(0.38f), arrow.length() + t[0].length() + 1, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return s;
    }

    static RemoteViews buildNext(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_next);
        v.setInt(R.id.root, "setBackgroundResource", bgRes(k, st));
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, st.hijri);
        v.setTextViewText(R.id.w_name, twoNames(label(st.next, k, st.ram, false), label(st.next, k, st.ram, true)));
        v.setTextViewText(R.id.w_time, timeText(fmt(st.nextMin, k.h24, urdu(k)), urdu(k)));
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, urdu(k));
        v.setTextColor(R.id.w_cd, accent(st));
        eventLine(v, st);
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static final int[] CELL = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5};
    static final int[] NAME = {R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5};
    static final int[] TIME = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5};

    static RemoteViews buildDay(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_day);
        v.setInt(R.id.root, "setBackgroundResource", bgRes(k, st));
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(st.today[0], st.today[1] - 1, st.today[2]);
        boolean ur = urdu(k);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        String date = ur ? WD_UR[dow] + "، " + st.today[2] + " " + MO_UR[st.today[1] - 1]
                         : WD[dow] + ", " + st.today[2] + " " + MO[st.today[1] - 1];
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, date + "  \u2022  " + st.hijri);
        v.setTextViewText(R.id.w_next, label(st.next, k, st.ram, false) + " " + join(fmt(st.nextMin, k.h24, ur)));
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, ur);
        for (int i = 0; i < 6; i++) {
            int key = DAY_CELLS[i];
            boolean on = key == st.hl;
            v.setTextViewText(NAME[i], label(key, k, st.ram, false));
            v.setTextViewText(TIME[i], fmt(st.tm[key], k.h24)[0]);
            v.setTextColor(NAME[i], on ? accent(st) : SOFT);
            v.setTextColor(TIME[i], on ? accent(st) : WHITE);
            v.setInt(CELL[i], "setBackgroundResource", on ? cellOn(st) : R.drawable.wg_cell_off);
        }
        v.setTextColor(R.id.w_next, accent(st));
        v.setTextColor(R.id.w_cd, accent(st));
        eventLine(v, st);
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    // ---------- Daily saying ----------
    private static JSONArray quotes;

    static JSONArray quotes(Context ctx) {
        if (quotes != null) return quotes;
        try {
            InputStream in = ctx.getAssets().open("quotes.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            quotes = new JSONArray(new String(out.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            quotes = new JSONArray();
        }
        return quotes;
    }

    /** Same rule as the app: days since 1 Jan 2026 (Pakistan date), wrapped around the list. */
    static JSONArray quoteToday(Context ctx, int[] today) {
        JSONArray all = quotes(ctx);
        int n = all.length();
        if (n == 0) return null;
        long diff = PrayerCalc.utcMs(today, 0, "UTC") - PrayerCalc.utcMs(new int[]{2026, 1, 1}, 0, "UTC");
        long days = diff >= 0 ? diff / 86400000L : -((-diff + 86399999L) / 86400000L);
        int i = (int) (((days % n) + n) % n);
        return all.optJSONArray(i);
    }

    static RemoteViews buildQuote(Context ctx, Cfg k, State st) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_quote);
        v.setInt(R.id.root, "setBackgroundResource", bgRes(k, st));
        boolean ur = urdu(k);
        JSONArray q = quoteToday(ctx, st.today);
        if (q != null) {
            int num = q.optInt(0, 0);
            v.setTextViewText(R.id.q_text, q.optString(ur ? 2 : 1, ""));
            v.setTextViewText(R.id.q_ref, ur ? "امام علیؑ، نہج البلاغہ، حکمت " + num : "Imam Ali (as), Nahj al-Balagha, Saying " + num);
        }
        v.setTextViewText(R.id.q_title, st.event != null ? st.event : (ur ? "آج کا قول" : "Saying of the day"));
        v.setTextColor(R.id.q_title, accent(st));
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static String join(String[] t) { return t[1].isEmpty() ? t[0] : t[0] + " " + t[1]; }

    // ---------- Sizing: the widget fills whatever space it is given ----------
    /** width and height of a placed widget in dp (portrait: narrowest width, tallest height); 0 when unknown */
    static float[] sizeOf(AppWidgetManager m, int id) {
        try {
            Bundle o = m.getAppWidgetOptions(id);
            if (Build.VERSION.SDK_INT >= 31) {
                java.util.ArrayList<android.util.SizeF> sizes = o.getParcelableArrayList(AppWidgetManager.OPTION_APPWIDGET_SIZES);
                if (sizes != null && !sizes.isEmpty()) {
                    // portrait size: the narrowest width and the tallest height the launcher reports
                    float w = Float.MAX_VALUE, h = 0;
                    for (android.util.SizeF z : sizes) { w = Math.min(w, z.getWidth()); h = Math.max(h, z.getHeight()); }
                    if (w > 0 && w < Float.MAX_VALUE && h > 0) return new float[]{w, h};
                }
            }
            return new float[]{o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0), o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)};
        } catch (Exception e) {
            return new float[]{0, 0};
        }
    }

    static void sp(RemoteViews v, int id, float size) { v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, size); }

    static int px(Context ctx, float dp) { return Math.round(dp * ctx.getResources().getDisplayMetrics().density); }

    /** padding that grows a little with the widget, so text never touches the border and never floats in a big frame */
    static int pad(Context ctx, float W, float H) {
        if (W <= 0 || H <= 0) return px(ctx, 12);
        float m = Math.min(W, H);
        return px(ctx, Math.max(8f, Math.min(16f, m * 0.085f)));
    }

    /** Next prayer: the text itself auto-sizes (see widget_next.xml); here only lines that would be too cramped step aside. */
    static void fitNext(Context ctx, RemoteViews v, State st, float W, float H) {
        boolean ev = st.event != null;
        float h = H <= 0 ? 170 : H;
        v.setViewVisibility(R.id.w_city, h >= 96 ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_hijri, h >= (ev ? 165 : 120) ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_event, ev && h >= 118 ? View.VISIBLE : View.GONE);
        int p = pad(ctx, W, H);
        v.setViewPadding(R.id.root, p, p, p, p);
    }

    /** Today's times: rows share the height and auto-size; on a short widget the Hijri date, countdown and banner step aside. */
    static void fitDay(Context ctx, RemoteViews v, State st, float W, float H) {
        float h = H <= 0 ? 150 : H;
        v.setViewVisibility(R.id.w_hijri, h >= 100 ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_cd, h >= 100 ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_event, st.event != null && h >= 135 ? View.VISIBLE : View.GONE);
        int p = pad(ctx, W, H);
        v.setViewPadding(R.id.root, p, p, p, p);
    }

    /** Saying of the day: the saying auto-sizes; title and reference scale gently, and the reference steps aside when short. */
    static void fitQuote(Context ctx, RemoteViews v, float W, float H) {
        float s = (W <= 0 || H <= 0) ? 1 : Math.max(0.85f, Math.min(1.3f, Math.min(H / 150f, W / 260f)));
        sp(v, R.id.q_title, 12 * s);
        sp(v, R.id.q_ref, 11 * s);
        v.setViewVisibility(R.id.q_ref, H > 0 && H < 105 ? View.GONE : View.VISIBLE);
        int p = pad(ctx, W, H);
        v.setViewPadding(R.id.root, p, p, p, p);
    }


    // ---------- Sky widget: the app's top card ----------
    static final String[] WD_EN = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    static final String[] MO_EN = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    static String dateLine(int[] ymd, boolean ur) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.clear(); c.set(ymd[0], ymd[1] - 1, ymd[2]);
        int wd = c.get(java.util.Calendar.DAY_OF_WEEK) - 1;
        return ur ? WD_UR[wd] + "، " + ymd[2] + " " + MO_UR[ymd[1] - 1] : WD_EN[wd] + ", " + ymd[2] + " " + MO_EN[ymd[1] - 1];
    }

    static RemoteViews buildSky(Context ctx, Cfg k, State st, long nowMs, float W, float H) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_sky);
        boolean ur = urdu(k);
        float dens = ctx.getResources().getDisplayMetrics().density;
        float w = W > 0 ? W : 330, h = H > 0 ? H : 300;
        double alt = SkyRenderer.sunAltitude(nowMs, k.lat, k.lng);
        String mood = st.mood;
        // background: a soft gradient, kept small (pictures travel to the launcher in one message)
        float sc = 0.8f;
        v.setImageViewBitmap(R.id.s_bg, SkyRenderer.background(Math.round(w * sc), Math.round(h * sc), 24 * sc, alt, mood, sc));

        // Same proportions as the app's card: text sizes follow the widget's size (u = 1 on a 360 dp wide card)
        float u = Math.max(0.6f, Math.min(1.25f, Math.min(w / 360f, h / 400f)));
        float pad = 14;
        float header = (20 + 8 + 15 + 4 + 15) * u + (st.event != null ? 17 * u : 0);
        float bottom = (14 + 4 + 32 + 6 + 14) * u + 6;
        float innerW = w - 2 * pad;
        float sceneHMax = h - 2 * pad - header - bottom - 4;
        float sceneW = Math.max(100, Math.min(innerW, sceneHMax * (SkyRenderer.W + 2 * SkyRenderer.MX) / (SkyRenderer.H + SkyRenderer.MB)));
        int side = Math.round((innerW - sceneW) / 2 * dens);
        v.setViewPadding(R.id.s_scene, side, 0, side, 0);

        int[] yd = PrayerCalc.schedule(PrayerCalc.addDays(st.today, -1), k.lat, k.lng, k.method, k.offsets, k.tz);
        int[] nx = PrayerCalc.schedule(PrayerCalc.addDays(st.today, 1), k.lat, k.lng, k.method, k.offsets, k.tz);
        int[] keys = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
        String[] names = new String[6];
        for (int i = 0; i < 6; i++) names[i] = label(keys[i], k, false, false);
        int sceneW_px = Math.min(520, Math.round(sceneW * Math.min(dens, 2f)));
        v.setImageViewBitmap(R.id.s_scene, SkyRenderer.scene(Math.max(120, sceneW_px), alt, mood, st.hm, st.tm, yd, nx, st.now, nowMs, k.lat, k.lng, names, ur));

        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.s_date, dateLine(st.today, ur));
        v.setTextViewText(R.id.w_hijri, st.hijri);
        String nextLbl = ur ? "\u0627\u06AF\u0644\u06CC \u0646\u0645\u0627\u0632" : "Next";
        if (st.ramCard) nextLbl = ur ? "\u0631\u0645\u0636\u0627\u0646 \u0627\u0644\u0645\u0628\u0627\u0631\u06A9" + (st.ramDay > 0 ? " \u00B7 \u0631\u0648\u0632\u06C1 " + st.ramDay : "")
                                     : "Ramadan" + (st.ramDay > 0 ? " \u00B7 Roza " + st.ramDay : "");
        v.setTextViewText(R.id.s_nextlbl, nextLbl);
        v.setTextViewText(R.id.w_name, twoNames(label(st.next, k, st.ram, false), label(st.next, k, st.ram, true)));
        v.setTextViewText(R.id.w_time, timeText(fmt(st.nextMin, k.h24, ur), ur, false));
        v.setTextViewText(R.id.s_arrow, ur ? "\u2190" : "\u2192");
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, ur);
        eventLine(v, st);
        sp(v, R.id.w_city, 20 * u); sp(v, R.id.s_date, 15 * u); sp(v, R.id.w_hijri, 15 * u); sp(v, R.id.w_event, 13 * u);
        sp(v, R.id.s_nextlbl, 14 * u); sp(v, R.id.w_name, 32 * u); sp(v, R.id.w_cd, 14 * u); sp(v, R.id.s_arrow, 22 * u); sp(v, R.id.w_time, 44 * u);
        int p = px(ctx, pad);
        v.setViewPadding(R.id.s_in, p, p, p, p);
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    /** Redraw every placed widget and schedule the next redraw at the next prayer, Maghrib or midnight. */
    public static void updateAll(Context ctx) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] a = m.getAppWidgetIds(new ComponentName(ctx, NextPrayerWidget.class));
            int[] b = m.getAppWidgetIds(new ComponentName(ctx, DayTimesWidget.class));
            int[] q = m.getAppWidgetIds(new ComponentName(ctx, QuoteWidget.class));
            int[] sk = m.getAppWidgetIds(new ComponentName(ctx, SkyWidget.class));
            if (a.length == 0 && b.length == 0 && q.length == 0 && sk.length == 0) return;
            Cfg k = load(ctx);
            long now = System.currentTimeMillis();
            State st = state(k, now);
            mood(ctx, k, st);
            // each placed widget is drawn for its own size
            for (int id : a) { RemoteViews v = buildNext(ctx, k, st, now); float[] z = sizeOf(m, id); fitNext(ctx, v, st, z[0], z[1]); m.updateAppWidget(id, v); }
            for (int id : b) { RemoteViews v = buildDay(ctx, k, st, now); float[] z = sizeOf(m, id); fitDay(ctx, v, st, z[0], z[1]); m.updateAppWidget(id, v); }
            for (int id : q) { RemoteViews v = buildQuote(ctx, k, st); float[] z = sizeOf(m, id); fitQuote(ctx, v, z[0], z[1]); m.updateAppWidget(id, v); }
            for (int id : sk) {
                try { float[] z = sizeOf(m, id); m.updateAppWidget(id, buildSky(ctx, k, st, now, z[0], z[1])); } catch (Throwable ignored) { }
            }
            // the sky widget's sun and moon move: redraw it every 10 minutes while one is placed
            long at = sk.length > 0 ? Math.min(st.refreshAt, now + 10 * 60000L) : st.refreshAt;
            scheduleTick(ctx, at);
        } catch (Exception ignored) { }
    }

    static void scheduleTick(Context ctx, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, WidgetRefreshReceiver.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7, i, piFlags());
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}

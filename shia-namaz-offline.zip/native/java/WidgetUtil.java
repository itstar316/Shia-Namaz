package com.javediqbal.shianamaz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.TimeZone;

/** Builds and refreshes the home-screen widgets. Settings arrive from the app through AppBridgePlugin. */
public final class WidgetUtil {
    private WidgetUtil() {}

    static final String PREFS = "shianamaz_widget";
    static final String ACTION_TICK = "com.javediqbal.shianamaz.WIDGET_TICK";
    static final String[] EN = {"Imsak", "Fajr", "Sunrise", "Zuhr", "Asr", "Sunset", "Maghrib", "Isha", "Midnight"};
    static final String[] UR = {"امساک", "فجر", "طلوعِ آفتاب", "ظہر", "عصر", "غروبِ آفتاب", "مغرب", "عشاء", "نصف شب"};
    static final int[] ALERT = {PrayerCalc.IMSAK, PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final int[] DAY_CELLS = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final String[] WD = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static final String[] WD_UR = {"اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"};
    static final String[] MO_UR = {"جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"};
    static final String[] MO = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final int WHITE = Color.WHITE, SOFT = 0xD9FFFFFF, GOLD = 0xFFF2C26B;

    static final class Cfg {
        double lat = 24.8607, lng = 67.0011;
        String name = "Karachi", method = "qum", lang = "ur", ramadan = "auto", tz = "Asia/Karachi";
        boolean h24 = false;
        int hijri = -1, glass = 1;
        int[] offsets = new int[9];
        String[] months = {"Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Awwal", "Jumada al-Thani",
            "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul Qadah", "Dhul Hijjah"};
    }

    static final class State {
        int[] today;
        int now, next, nextMin, hl;
        long nextUtc, refreshAt;
        boolean ram;
        int[] tm;
        String hijri;
    }

    static Cfg load(Context c) {
        Cfg k = new Cfg();
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("cfg", null);
            if (s == null) return k;
            JSONObject o = new JSONObject(s);
            k.lat = o.optDouble("lat", k.lat);
            k.lng = o.optDouble("lng", k.lng);
            k.name = o.optString("name", k.name);
            k.method = o.optString("method", k.method);
            k.lang = o.optString("lang", k.lang);
            k.ramadan = o.optString("ramadan", k.ramadan);
            k.tz = o.optString("tz", k.tz);
            k.h24 = o.optBoolean("h24", false);
            k.hijri = o.optInt("hijri", -1);
            k.glass = o.optInt("glass", 1);
            JSONObject off = o.optJSONObject("offsets");
            if (off != null) for (int i = 0; i < 9; i++) k.offsets[i] = off.optInt(PrayerCalc.KEYS[i], 0);
            JSONArray ms = o.optJSONArray("months");
            if (ms != null && ms.length() == 12) for (int i = 0; i < 12; i++) k.months[i] = ms.optString(i, k.months[i]);
        } catch (Exception ignored) { }
        return k;
    }

    static State state(Cfg k, long nowMs) {
        State st = new State();
        int[] p = PrayerCalc.pktNow(nowMs, k.tz);
        st.today = new int[]{p[0], p[1], p[2]};
        st.now = p[3];
        st.tm = PrayerCalc.schedule(st.today, k.lat, k.lng, k.method, k.offsets, k.tz);
        int[] nx = PrayerCalc.schedule(PrayerCalc.addDays(st.today, 1), k.lat, k.lng, k.method, k.offsets, k.tz);
        // Imsak is not a prayer: it only counts on Ramadan days, as the end of Sehri
        boolean ramToday = isRamDay(k, st.today), ramTomorrow = isRamDay(k, PrayerCalc.addDays(st.today, 1));
        st.next = -1;
        for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramToday) continue;
            if (st.tm[i] > st.now && (st.next < 0 || st.tm[i] < st.nextMin)) { st.next = i; st.nextMin = st.tm[i]; }
        }
        if (st.next < 0) for (int i : ALERT) {
            if (i == PrayerCalc.IMSAK && !ramTomorrow) continue;
            if (st.next < 0 || nx[i] + 1440 < st.nextMin) { st.next = i; st.nextMin = nx[i] + 1440; }
        }
        st.nextUtc = PrayerCalc.utcMs(st.today, st.nextMin, k.tz);
        st.hl = st.next == PrayerCalc.IMSAK ? PrayerCalc.FAJR : st.next;
        boolean night = st.now >= st.tm[PrayerCalc.MAGHRIB];
        int[] h = PrayerCalc.hijri(night ? PrayerCalc.addDays(st.today, 1) : st.today, k.hijri);
        String mon = k.months[Math.max(0, Math.min(11, h[1] - 1))];
        boolean ur = !"en".equals(k.lang);
        st.hijri = night ? (ur ? "شبِ " + h[0] + " " + mon : "Night of " + h[0] + " " + mon) : h[0] + " " + mon + " " + h[2];
        st.ram = "on".equals(k.ramadan) || (!"off".equals(k.ramadan) && h[1] == 9);
        long midnight = PrayerCalc.utcMs(st.today, 1440, k.tz);
        long maghrib = PrayerCalc.utcMs(st.today, st.tm[PrayerCalc.MAGHRIB], k.tz);
        long at = Math.min(st.nextUtc, midnight);
        if (maghrib > nowMs) at = Math.min(at, maghrib);
        st.refreshAt = Math.max(at, nowMs + 30000L) + 2000L;
        return st;
    }

    static boolean urdu(Cfg k) { return !"en".equals(k.lang); }

    /** prayer label in the chosen language; in Ramadan, Imsak and Maghrib read as Sehri and Iftar */
    static String label(int key, Cfg k, boolean ram, boolean other) {
        boolean ur = urdu(k) != other;
        if (ram && key == PrayerCalc.IMSAK) return ur ? "سحری کا اختتام" : "Sehri ends";
        if (ram && key == PrayerCalc.MAGHRIB) return ur ? "افطار" : "Iftar";
        return ur ? UR[key] : EN[key];
    }

    static String period(int h, boolean ur) {
        if (!ur) return h >= 12 ? "pm" : "am";
        if (h >= 4 && h < 12) return "صبح";
        if (h >= 12 && h < 16) return "دوپہر";
        if (h >= 16 && h < 19) return "شام";
        return "رات";
    }

    static boolean isRamDay(Cfg k, int[] ymd) {
        if ("on".equals(k.ramadan)) return true;
        if ("off".equals(k.ramadan)) return false;
        return PrayerCalc.hijri(ymd, k.hijri)[1] == 9;
    }

    static String[] fmt(int min, boolean h24) { return fmt(min, h24, false); }

    static String[] fmt(int min, boolean h24, boolean ur) {
        int m = ((min % 1440) + 1440) % 1440, h = m / 60, mm = m % 60;
        String two = (mm < 10 ? "0" : "") + mm;
        if (h24) return new String[]{(h < 10 ? "0" : "") + h + ":" + two, ""};
        String ap = period(h, ur);
        h = h % 12;
        if (h == 0) h = 12;
        return new String[]{h + ":" + two, ap};
    }

    static int glassRes(int g) {
        switch (g) {
            case 0: return R.drawable.wg_glass0;
            case 2: return R.drawable.wg_glass2;
            case 3: return R.drawable.wg_glass3;
            default: return R.drawable.wg_glass1;
        }
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent openApp(Context ctx) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (i == null) i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 0, i, piFlags());
    }

    static void countdown(RemoteViews v, int id, long target, long nowMs, boolean ur) {
        if (Build.VERSION.SDK_INT >= 24) {
            long base = SystemClock.elapsedRealtime() + Math.max(0L, target - nowMs);
            v.setChronometer(id, base, ur ? "%s باقی" : "in %s", true);
            v.setChronometerCountDown(id, true);
            v.setViewVisibility(id, View.VISIBLE);
        } else {
            v.setViewVisibility(id, View.GONE);
        }
    }

    static RemoteViews buildNext(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_next);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, st.hijri);
        v.setTextViewText(R.id.w_name, label(st.next, k, st.ram, false));
        v.setTextViewText(R.id.w_ur, label(st.next, k, st.ram, true));
        String[] t = fmt(st.nextMin, k.h24, urdu(k));
        v.setTextViewText(R.id.w_time, t[0]);
        v.setTextViewText(R.id.w_ampm, t[1]);
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, urdu(k));
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static final int[] CELL = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5};
    static final int[] NAME = {R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5};
    static final int[] TIME = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5};

    static RemoteViews buildDay(Context ctx, Cfg k, State st, long nowMs) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_day);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(st.today[0], st.today[1] - 1, st.today[2]);
        boolean ur = urdu(k);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        String date = ur ? WD_UR[dow] + "، " + st.today[2] + " " + MO_UR[st.today[1] - 1]
                         : WD[dow] + ", " + st.today[2] + " " + MO[st.today[1] - 1];
        v.setTextViewText(R.id.w_city, k.name);
        v.setTextViewText(R.id.w_hijri, date + "  \u2022  " + st.hijri);
        v.setTextViewText(R.id.w_next, label(st.next, k, st.ram, false) + " " + join(fmt(st.nextMin, k.h24, ur)));
        countdown(v, R.id.w_cd, st.nextUtc, nowMs, ur);
        for (int i = 0; i < 6; i++) {
            int key = DAY_CELLS[i];
            boolean on = key == st.hl;
            v.setTextViewText(NAME[i], label(key, k, st.ram, false));
            v.setTextViewText(TIME[i], fmt(st.tm[key], k.h24)[0]);
            v.setTextColor(NAME[i], on ? GOLD : SOFT);
            v.setTextColor(TIME[i], on ? GOLD : WHITE);
            v.setInt(CELL[i], "setBackgroundResource", on ? R.drawable.wg_cell_on : R.drawable.wg_cell_off);
        }
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    // ---------- Daily saying ----------
    private static JSONArray quotes;

    static JSONArray quotes(Context ctx) {
        if (quotes != null) return quotes;
        try {
            InputStream in = ctx.getAssets().open("quotes.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            quotes = new JSONArray(new String(out.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            quotes = new JSONArray();
        }
        return quotes;
    }

    /** Same rule as the app: days since 1 Jan 2026 (Pakistan date), wrapped around the list. */
    static JSONArray quoteToday(Context ctx, int[] today) {
        JSONArray all = quotes(ctx);
        int n = all.length();
        if (n == 0) return null;
        long diff = PrayerCalc.utcMs(today, 0, "UTC") - PrayerCalc.utcMs(new int[]{2026, 1, 1}, 0, "UTC");
        long days = diff >= 0 ? diff / 86400000L : -((-diff + 86399999L) / 86400000L);
        int i = (int) (((days % n) + n) % n);
        return all.optJSONArray(i);
    }

    static RemoteViews buildQuote(Context ctx, Cfg k, State st) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_quote);
        v.setInt(R.id.root, "setBackgroundResource", glassRes(k.glass));
        boolean ur = urdu(k);
        JSONArray q = quoteToday(ctx, st.today);
        if (q != null) {
            int num = q.optInt(0, 0);
            v.setTextViewText(R.id.q_text, q.optString(ur ? 2 : 1, ""));
            v.setTextViewText(R.id.q_ref, ur ? "امام علیؑ، نہج البلاغہ، حکمت " + num : "Imam Ali (as), Nahj al-Balagha, Saying " + num);
        }
        v.setTextViewText(R.id.q_title, ur ? "آج کا قول" : "Saying of the day");
        v.setOnClickPendingIntent(R.id.root, openApp(ctx));
        return v;
    }

    static String join(String[] t) { return t[1].isEmpty() ? t[0] : t[0] + " " + t[1]; }

    // ---------- Sizing: the widget fills whatever space it is given ----------
    /** width and height of a placed widget in dp (portrait: narrowest width, tallest height); 0 when unknown */
    static float[] sizeOf(AppWidgetManager m, int id) {
        try {
            Bundle o = m.getAppWidgetOptions(id);
            return new float[]{o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0), o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)};
        } catch (Exception e) {
            return new float[]{0, 0};
        }
    }

    static void sp(RemoteViews v, int id, float size) { v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, size); }

    static int px(Context ctx, float dp) { return Math.round(dp * ctx.getResources().getDisplayMetrics().density); }

    /**
     * Next prayer: rows are city, Hijri date, prayer name, time, countdown. The text is scaled to fill the height
     * and width. If even a slightly smaller size would not fit, the Hijri date and then the city are left out,
     * so the prayer, its time and the countdown always stay readable.
     */
    static float fitNext(Context ctx, RemoteViews v, float W, float H) {
        if (W <= 0 || H <= 0) return 1;
        float fs = ctx.getResources().getConfiguration().fontScale;
        float city = 13 * 1.32f, hij = 11 * 1.32f, name = 22 * 1.3f + 8, time = 36 * 1.22f, cd = 13 * 1.32f;
        boolean showCity = true, showHij = true;
        float s = 1;
        for (int c = 0; c < 3; c++) {
            showHij = c == 0;
            showCity = c < 2;
            float sum = ((showCity ? city : 0) + (showHij ? hij : 0) + name + time + cd) * fs;
            float pad = 14;
            s = Math.min(Math.min((H - 2 * pad) / sum, (W - 2 * pad) / (150 * fs)), 1.9f);
            if (s >= 0.88f) break;
        }
        s = Math.max(s, 0.62f);
        v.setViewVisibility(R.id.w_city, showCity ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_hijri, showHij ? View.VISIBLE : View.GONE);
        sp(v, R.id.w_city, 13 * s); sp(v, R.id.w_hijri, 11 * s); sp(v, R.id.w_name, 22 * s); sp(v, R.id.w_ur, 15 * s);
        sp(v, R.id.w_time, 36 * s); sp(v, R.id.w_ampm, 14 * s); sp(v, R.id.w_cd, 13 * s);
        int p = px(ctx, 10 + 6 * Math.min(s, 1.3f));
        v.setViewPadding(R.id.root, p, p, p, p);
        return s;
    }

    /** Today's times: a header row and six cells. Scaled to fit; on a very short widget the Hijri line and countdown step aside. */
    static float fitDay(Context ctx, RemoteViews v, float W, float H) {
        if (W <= 0 || H <= 0) return 1;
        float fs = ctx.getResources().getConfiguration().fontScale;
        float cell = 14 + 11 * 1.3f + 2 + 16 * 1.25f;
        boolean full = true;
        float s = 1;
        for (int c = 0; c < 2; c++) {
            full = c == 0;
            float head = full ? Math.max(14 * 1.3f + 11 * 1.3f, 12 * 1.3f * 2) : 14 * 1.3f;
            float sum = (head + 10 + cell) * fs;
            float pad = 12;
            s = Math.min(Math.min((H - 2 * pad) / sum, (W - 2 * pad) / (300 * fs)), 1.6f);
            if (s >= 0.86f) break;
        }
        s = Math.max(s, 0.62f);
        v.setViewVisibility(R.id.w_hijri, full ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_cd, full ? View.VISIBLE : View.GONE);
        sp(v, R.id.w_city, 14 * s); sp(v, R.id.w_hijri, 11 * s); sp(v, R.id.w_next, 12 * s); sp(v, R.id.w_cd, 12 * s);
        // when the widget is taller than the text needs, the six cells grow to use the space
        float head = full ? Math.max(14 * 1.3f + 11 * 1.3f, 12 * 1.3f * 2) : 14 * 1.3f;
        float extra = (H - 2 * 12) - (head + 10 + cell) * fs * s;
        int cp = px(ctx, 7 * s + Math.max(0, Math.min(extra * 0.4f, 34)));
        for (int i = 0; i < 6; i++) {
            sp(v, NAME[i], 11 * s);
            sp(v, TIME[i], 16 * s);
            v.setViewPadding(CELL[i], 0, cp, 0, cp);
        }
        int p = px(ctx, 9 + 5 * Math.min(s, 1.3f));
        v.setViewPadding(R.id.root, p, p, p, p);
        return s;
    }

    /** Saying of the day: the saying itself already resizes; the title and reference scale too, and the reference steps aside when short. */
    static float fitQuote(Context ctx, RemoteViews v, float W, float H) {
        if (W <= 0 || H <= 0) return 1;
        float s = Math.max(0.8f, Math.min(1.35f, Math.min(H / 150f, W / 260f)));
        sp(v, R.id.q_title, 12 * s);
        sp(v, R.id.q_ref, 11 * s);
        v.setViewVisibility(R.id.q_ref, H < 105 ? View.GONE : View.VISIBLE);
        return s;
    }

    /** Redraw every placed widget and schedule the next redraw at the next prayer, Maghrib or midnight. */
    public static void updateAll(Context ctx) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] a = m.getAppWidgetIds(new ComponentName(ctx, NextPrayerWidget.class));
            int[] b = m.getAppWidgetIds(new ComponentName(ctx, DayTimesWidget.class));
            int[] q = m.getAppWidgetIds(new ComponentName(ctx, QuoteWidget.class));
            if (a.length == 0 && b.length == 0 && q.length == 0) return;
            Cfg k = load(ctx);
            long now = System.currentTimeMillis();
            State st = state(k, now);
            // each placed widget is drawn for its own size, so resizing scales the text instead of cutting it off
            for (int id : a) { RemoteViews v = buildNext(ctx, k, st, now); float[] z = sizeOf(m, id); fitNext(ctx, v, z[0], z[1]); m.updateAppWidget(id, v); }
            for (int id : b) { RemoteViews v = buildDay(ctx, k, st, now); float[] z = sizeOf(m, id); fitDay(ctx, v, z[0], z[1]); m.updateAppWidget(id, v); }
            for (int id : q) { RemoteViews v = buildQuote(ctx, k, st); float[] z = sizeOf(m, id); fitQuote(ctx, v, z[0], z[1]); m.updateAppWidget(id, v); }
            scheduleTick(ctx, st.refreshAt);
        } catch (Exception ignored) { }
    }

    static void scheduleTick(Context ctx, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, WidgetRefreshReceiver.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7, i, piFlags());
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}

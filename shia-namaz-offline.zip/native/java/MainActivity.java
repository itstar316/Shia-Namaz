package com.javediqbal.shianamaz;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.getcapacitor.BridgeActivity;

/** Draws the app edge to edge, behind transparent status and navigation bars, and tells the page their sizes. */
public class MainActivity extends BridgeActivity {
    static volatile float insetTop = 0, insetBottom = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AppBridgePlugin.class);
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setStatusBarContrastEnforced(false);
            w.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        final WebView wv = getBridge().getWebView();
        final float density = getResources().getDisplayMetrics().density;
        ViewCompat.setOnApplyWindowInsetsListener(wv, (View v, WindowInsetsCompat insets) -> {
            Insets s = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            insetTop = s.top / density;
            insetBottom = s.bottom / density;
            // the keyboard: when it is open the app is drawn behind it, so tell the page how tall it is
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            float kb = ime.bottom / density;
            final String js = "window.__insets&&window.__insets(" + insetTop + "," + insetBottom + "," + kb + ")";
            v.post(() -> wv.evaluateJavascript(js, null));
            return insets;
        });
        ViewCompat.requestApplyInsets(wv);
    }
}

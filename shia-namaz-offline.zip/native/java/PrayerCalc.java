package com.javediqbal.shianamaz;

import java.util.Calendar;
import java.util.TimeZone;


/** Same astronomy as the app (Ja'fari methods, Pakistan time, safe rounding). Used by the widgets. */
public final class PrayerCalc {
    private PrayerCalc() {}
    static final double R = Math.PI / 180.0;
    public static final int TZ = 5; // Pakistan, used only if no time zone is known
    public static final String[] KEYS = {"imsak", "fajr", "sunrise", "dhuhr", "asr", "sunset", "maghrib", "isha", "midnight"};
    public static final int IMSAK = 0, FAJR = 1, SUNRISE = 2, DHUHR = 3, ASR = 4, SUNSET = 5, MAGHRIB = 6, ISHA = 7, MIDNIGHT = 8;

    static double sn(double d) { return Math.sin(d * R); }
    static double cs(double d) { return Math.cos(d * R); }
    static double tn(double d) { return Math.tan(d * R); }
    static double asn(double x) { return Math.asin(x) / R; }
    static double acs(double x) { return Math.acos(x) / R; }
    static double at2(double y, double x) { return Math.atan2(y, x) / R; }
    static double acot(double x) { return Math.atan(1.0 / x) / R; }
    static double fixA(double a) { a = a % 360.0; return a < 0 ? a + 360.0 : a; }
    static double fixH(double h) { h = h % 24.0; return h < 0 ? h + 24.0 : h; }

    static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double A = Math.floor(y / 100.0), B = 2 - A + Math.floor(A / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
    }

    /** returns {declination, equation of time} */
    static double[] sunPos(double jd) {
        double D = jd - 2451545.0;
        double g = fixA(357.529 + 0.98560028 * D), q = fixA(280.459 + 0.98564736 * D);
        double L = fixA(q + 1.915 * sn(g) + 0.020 * sn(2 * g)), e = 23.439 - 0.00000036 * D;
        double RA = fixH(at2(cs(e) * sn(L), cs(L)) / 15.0);
        double eqt = q / 15.0 - RA;
        eqt -= 24.0 * Math.round(eqt / 24.0);
        return new double[]{asn(sn(e) * sn(L)), eqt};
    }

    static double[] angles(String method) {
        if ("tehran".equals(method)) return new double[]{17.7, 4.5, 14};
        return new double[]{16, 4, 14};
    }

    /** {fajr, sunrise, noon, asr, sunset, maghrib, isha} in decimal hours, Pakistan time */
    static double[] rawTimes(int y, int m, int d, double lat, double lng, String method, double tzH) {
        final double[] ang = angles(method);
        final double jd = julian(y, m, d) - lng / 360.0;
        double[] T = {5, 6, 12, 13, 18, 18, 18};
        for (int it = 0; it < 2; it++) {
            T = new double[]{
                angleT(jd, lat, ang[0], T[0], true), angleT(jd, lat, 0.833, T[1], true), mid(jd, T[2]),
                asrT(jd, lat, T[3]), angleT(jd, lat, 0.833, T[4], false), angleT(jd, lat, ang[1], T[5], false),
                angleT(jd, lat, ang[2], T[6], false)};
        }
        // high latitudes: angle-based rule, the same as the app
        double night = 24 - (T[4] - T[1]);
        if (!Double.isNaN(night)) {
            T[0] = highLat(T[0], T[1], ang[0], night, true);
            T[6] = highLat(T[6], T[4], ang[2], night, false);
            T[5] = highLat(T[5], T[4], ang[1], night, false);
        }
        double adj = tzH - lng / 15.0;
        for (int i = 0; i < T.length; i++) T[i] += adj;
        return T;
    }
    static double mid(double jd, double t) { return fixH(12 - sunPos(jd + t / 24.0)[1]); }
    static double angleT(double jd, double lat, double ang, double t, boolean ccw) {
        double decl = sunPos(jd + t / 24.0)[0], n = mid(jd, t);
        double c = (-sn(ang) - sn(decl) * sn(lat)) / (cs(decl) * cs(lat));
        if (c < -1 || c > 1) return Double.NaN;
        double h = acs(c) / 15.0;
        return n + (ccw ? -h : h);
    }
    static double asrT(double jd, double lat, double t) {
        double decl = sunPos(jd + t / 24.0)[0];
        return angleT(jd, lat, -acot(1 + tn(Math.abs(lat - decl))), t, false);
    }

    static double highLat(double t, double base, double ang, double night, boolean before) {
        double portion = night * ang / 60.0;
        if (Double.isNaN(t)) return before ? base - portion : base + portion;
        double diff = before ? base - t : t - base;
        return diff > portion ? (before ? base - portion : base + portion) : t;
    }

    /** UTC offset in hours on a local date (taken at local noon), with summer time */
    public static double tzHours(String tz, int[] ymd) {
        TimeZone z = TimeZone.getTimeZone(tz == null ? "Asia/Karachi" : tz);
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(ymd[0], ymd[1] - 1, ymd[2], 12, 0, 0);
        long noon = c.getTimeInMillis();
        return z.getOffset(noon - z.getOffset(noon)) / 3600000.0;
    }

    /** minutes after local midnight for each of KEYS (may exceed 1440) */
    public static int[] schedule(int[] ymd, double lat, double lng, String method, int[] offsets, String tz) {
        double[] t = rawTimes(ymd[0], ymd[1], ymd[2], lat, lng, method, tzHours(tz, ymd));
        int[] n = addDays(ymd, 1);
        double[] tn = rawTimes(n[0], n[1], n[2], lat, lng, method, tzHours(tz, n));
        int[] r = {
            near(t[0] - 10 / 60.0), near(t[0]), near(t[1]), near(t[2]), near(t[3]),
            near(t[4]), near(t[5]), near(t[6]), near(t[4] + (tn[0] + 24 - t[4]) / 2)};
        if (offsets != null) for (int i = 0; i < r.length && i < offsets.length; i++) r[i] += offsets[i];
        return r;
    }
    static int up(double h) { return (int) Math.ceil(h * 60 - 1e-6); }
    static int down(double h) { return (int) Math.floor(h * 60 + 1e-6); }
    /** exact time rounded to the nearest minute, the same rule as the app */
    static int near(double h) { return (int) Math.round(h * 60); }

    public static int[] addDays(int[] ymd, int n) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(ymd[0], ymd[1] - 1, ymd[2]);
        c.add(Calendar.DAY_OF_MONTH, n);
        return new int[]{c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)};
    }

    /** {day, month, year} of the tabular Islamic calendar shifted by offset days */
    public static int[] hijri(int[] ymd, int offset) {
        int[] g = addDays(ymd, offset);
        long jdn = (long) Math.floor(julian(g[0], g[1], g[2]) + 0.5);
        long l = jdn - 1948440 + 10632;
        long n = (l - 1) / 10631;
        l = l - 10631 * n + 354;
        long j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238);
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29;
        long m = (24 * l) / 709, d = l - (709 * m) / 24, y = 30 * n + j - 30;
        return new int[]{(int) d, (int) m, (int) y};
    }

    /** local date and minutes since local midnight for a UTC instant: {y, m, d, minutes} */
    public static int[] pktNow(long utcMs, String tz) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(utcMs + TimeZone.getTimeZone(tz == null ? "Asia/Karachi" : tz).getOffset(utcMs));
        return new int[]{c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)};
    }

    /** UTC milliseconds of a local date plus minutes */
    public static long utcMs(int[] ymd, int minutes, String tz) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(ymd[0], ymd[1] - 1, ymd[2]);
        return c.getTimeInMillis() + (long) ((minutes - tzHours(tz, ymd) * 60) * 60000L);
    }
}

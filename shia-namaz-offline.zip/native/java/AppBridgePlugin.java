package com.javediqbal.shianamaz;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import android.media.RingtoneManager;
import android.media.Ringtone;
import android.os.PowerManager;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import org.json.JSONArray;
import android.view.Window;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Small bridge from the app's screens to Android: widget settings and notification settings. */
@CapacitorPlugin(name = "AppBridge")
public class AppBridgePlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String data = call.getString("data");
        if (data != null) {
            getContext().getSharedPreferences(WidgetUtil.PREFS, Context.MODE_PRIVATE).edit().putString("cfg", data).apply();
            WidgetUtil.updateAll(getContext());
            PrayerAlarm.schedule(getContext());
        }
        call.resolve();
    }

    @PluginMethod
    public void share(PluginCall call) {
        String text = call.getString("text");
        if (text == null) { call.resolve(); return; }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        Intent chooser = Intent.createChooser(send, null);
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { getContext().startActivity(chooser); } catch (Exception ignored) { }
        call.resolve();
    }

    /** Asks Android to let the app run without battery limits, so alarms and widgets stay on time. */
    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        Intent i = Build.VERSION.SDK_INT >= 23
            ? new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg))
            : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception e) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(d);
            } catch (Exception ignored) { }
        }
        call.resolve();
    }

    /** Text size = the phone's own font scale times the size chosen in the app. */
    @PluginMethod
    public void setTextSize(final PluginCall call) {
        Double m = call.getDouble("mult");
        double mult = m == null ? 1.0 : m;
        float fontScale = getContext().getResources().getConfiguration().fontScale;
        final int zoom = (int) Math.round(Math.min(1.6, Math.max(0.85, fontScale * mult)) * 100);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try { getBridge().getWebView().getSettings().setTextZoom(zoom); } catch (Exception ignored) { }
                call.resolve();
            }
        });
    }

    /** Light or dark icons in the status and navigation bars, to stay readable over the app's colours. */
    @PluginMethod
    public void setBars(final PluginCall call) {
        final boolean lightStatus = call.getBoolean("lightStatus", true);
        final boolean lightNav = call.getBoolean("lightNav", true);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                    c.setAppearanceLightStatusBars(!lightStatus);
                    c.setAppearanceLightNavigationBars(!lightNav);
                } catch (Exception ignored) { }
                call.resolve();
            }
        });
    }

    /** Status bar and navigation bar sizes in CSS pixels, read from the live window when possible. */
    @PluginMethod
    public void getInsets(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                float top = MainActivity.insetTop, bottom = MainActivity.insetBottom;
                android.content.res.Resources res = getContext().getResources();
                float d = res.getDisplayMetrics().density;
                try {
                    androidx.core.view.WindowInsetsCompat wi = androidx.core.view.ViewCompat.getRootWindowInsets(getBridge().getWebView());
                    if (wi != null) {
                        androidx.core.graphics.Insets s = wi.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()
                            | androidx.core.view.WindowInsetsCompat.Type.displayCutout());
                        top = s.top / d;
                        bottom = s.bottom / d;
                    }
                } catch (Exception ignored) { }
                if (top <= 0) {
                    int id = res.getIdentifier("status_bar_height", "dimen", "android");
                    if (id > 0) top = res.getDimensionPixelSize(id) / d;
                }
                JSObject o = new JSObject();
                o.put("top", top);
                o.put("bottom", bottom);
                call.resolve(o);
            }
        });
    }

    // ---------- Native prayer alerts ----------
    /** Saves the alert choices (on/off, which prayers, minutes before, Sehri wake-up, play on silent) and sets the next alert. */
    @PluginMethod
    public void setAlerts(PluginCall call) {
        String data = call.getString("data");
        if (data != null) PrayerAlarm.prefs(getContext()).edit().putString("alerts", data).apply();
        PrayerAlarm.schedule(getContext());
        alertStatus(call);
    }

    @PluginMethod
    public void alertStatus(PluginCall call) {
        Context c = getContext();
        JSObject o = new JSObject();
        o.put("nextAt", (double) PrayerAlarm.prefs(c).getLong("nextAt", 0));
        o.put("nextTitle", PrayerAlarm.prefs(c).getString("nextTitle", ""));
        o.put("exact", PrayerAlarm.exactAllowed(c));
        boolean battery = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            battery = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }
        o.put("batteryFree", battery);
        o.put("soundTitle", PrayerAlarm.prefs(c).getString("soundTitle", ""));
        call.resolve(o);
    }

    @PluginMethod
    public void testAlert(PluginCall call) { PrayerAlarm.test(getContext()); call.resolve(); }

    /** "Prayed" taps made on alerts while the app was closed; handed over once and then cleared. */
    @PluginMethod
    public void takePrayed(PluginCall call) {
        String q = PrayerAlarm.prefs(getContext()).getString("prayed", "[]");
        PrayerAlarm.prefs(getContext()).edit().putString("prayed", "[]").apply();
        JSObject o = new JSObject();
        o.put("list", q);
        call.resolve(o);
    }

    /** Lets the user grant "Alarms and reminders" so alerts arrive to the minute (Android 12 and newer). */
    @PluginMethod
    public void openExactAlarmSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Exception ignored) { }
        }
        call.resolve();
    }

    /** Opens Android's sound picker: an azan or any ringtone, alarm or notification sound on the phone. */
    @PluginMethod
    public void pickSound(PluginCall call) {
        Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        String cur = PrayerAlarm.prefs(getContext()).getString("sound", "");
        if (!cur.isEmpty()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur));
        startActivityForResult(call, i, "soundPicked");
    }

    @ActivityCallback
    private void soundPicked(PluginCall call, ActivityResult result) {
        JSObject o = new JSObject();
        Intent data = result.getData();
        Uri u = data == null ? null : (Uri) data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
        if (u != null) {
            String title = "";
            try {
                Ringtone r = RingtoneManager.getRingtone(getContext(), u);
                if (r != null) title = r.getTitle(getContext());
            } catch (Exception ignored) { }
            PrayerAlarm.prefs(getContext()).edit().putString("sound", u.toString()).putString("soundTitle", title).apply();
            o.put("title", title);
        }
        call.resolve(o);
    }

    @PluginMethod
    public void resetSound(PluginCall call) {
        PrayerAlarm.prefs(getContext()).edit().remove("sound").remove("soundTitle").apply();
        call.resolve();
    }

    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        String channel = call.getString("channel");
        Intent i;
        if (Build.VERSION.SDK_INT >= 26 && channel != null) {
            i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
            i.putExtra(Settings.EXTRA_CHANNEL_ID, channel);
        } else if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception e) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(d);
            } catch (Exception ignored) { }
        }
        call.resolve();
    }
}

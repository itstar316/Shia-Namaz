package com.javediqbal.shianamaz;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Small bridge from the app's screens to Android: widget settings and notification settings. */
@CapacitorPlugin(name = "AppBridge")
public class AppBridgePlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String data = call.getString("data");
        if (data != null) {
            getContext().getSharedPreferences(WidgetUtil.PREFS, Context.MODE_PRIVATE).edit().putString("cfg", data).apply();
            WidgetUtil.updateAll(getContext());
        }
        call.resolve();
    }

    @PluginMethod
    public void share(PluginCall call) {
        String text = call.getString("text");
        if (text == null) { call.resolve(); return; }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        Intent chooser = Intent.createChooser(send, null);
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { getContext().startActivity(chooser); } catch (Exception ignored) { }
        call.resolve();
    }

    /** Asks Android to let the app run without battery limits, so alarms and widgets stay on time. */
    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        Intent i = Build.VERSION.SDK_INT >= 23
            ? new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg))
            : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception e) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(d);
            } catch (Exception ignored) { }
        }
        call.resolve();
    }

    /** Text size = the phone's own font scale times the size chosen in the app. */
    @PluginMethod
    public void setTextSize(final PluginCall call) {
        Double m = call.getDouble("mult");
        double mult = m == null ? 1.0 : m;
        float fontScale = getContext().getResources().getConfiguration().fontScale;
        final int zoom = (int) Math.round(Math.min(1.6, Math.max(0.85, fontScale * mult)) * 100);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try { getBridge().getWebView().getSettings().setTextZoom(zoom); } catch (Exception ignored) { }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        String channel = call.getString("channel");
        Intent i;
        if (Build.VERSION.SDK_INT >= 26 && channel != null) {
            i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
            i.putExtra(Settings.EXTRA_CHANNEL_ID, channel);
        } else if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception e) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(d);
            } catch (Exception ignored) { }
        }
        call.resolve();
    }
}

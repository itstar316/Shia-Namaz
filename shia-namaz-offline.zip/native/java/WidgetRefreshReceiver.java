package com.javediqbal.shianamaz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Redraws the widgets at each prayer, at midnight, after a reboot and when the clock changes. */
public class WidgetRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        WidgetUtil.updateAll(context);
    }
}

package com.javediqbal.shianamaz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Redraws the widgets and re-sets the next prayer alert at each prayer, at midnight, after a reboot and when the clock changes. */
public class WidgetRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        WidgetUtil.updateAll(context);
        // alerts are set again after a restart, a clock or time-zone change and an app update
        PrayerAlarm.schedule(context);
    }
}

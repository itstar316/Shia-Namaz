package com.javediqbal.shianamaz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

/**
 * Native prayer alerts. Exactly one alarm is ever set: the next alert. When it fires, AlertReceiver plays it and
 * immediately sets the following one, so alerts keep coming without the app being opened. Alerts are also re-set
 * after a restart, a clock or time-zone change and an app update.
 */
public class PrayerAlarm {
    static final int RC = 7101, RC_TEST = 7102;

    static final class Alerts {
        boolean on = false, silent = false;
        boolean[] forKey = {true, true, false, true, true, false, true, true, false};
        int lead = 0, wake = 0;
        String sound = "", soundTitle = "";
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(WidgetUtil.PREFS, Context.MODE_PRIVATE); }

    static Alerts load(Context c) {
        Alerts a = new Alerts();
        try {
            String s = prefs(c).getString("alerts", null);
            if (s != null) {
                JSONObject o = new JSONObject(s);
                a.on = o.optBoolean("on", false);
                a.silent = o.optBoolean("silent", false);
                a.lead = o.optInt("lead", 0);
                a.wake = o.optInt("wake", 0);
                JSONObject f = o.optJSONObject("for");
                if (f != null) for (int i = 0; i < 9; i++) a.forKey[i] = f.optBoolean(PrayerCalc.KEYS[i], a.forKey[i]);
            }
            a.sound = prefs(c).getString("sound", "");
            a.soundTitle = prefs(c).getString("soundTitle", "");
        } catch (Exception ignored) { }
        return a;
    }

    /** The next alert strictly after {@code after}: {utc ms, prayer key (or -1 for the Sehri wake-up), minutes before, y, m, d, ramadan} */
    static long[] next(WidgetUtil.Cfg k, Alerts a, long after) {
        int[] p = PrayerCalc.pktNow(after, k.tz);
        int[] today = {p[0], p[1], p[2]};
        long[] best = null;
        for (int dd = 0; dd < 3; dd++) {
            int[] ymd = PrayerCalc.addDays(today, dd);
            int[] s = PrayerCalc.schedule(ymd, k.lat, k.lng, k.method, k.offsets, k.tz);
            boolean ram = WidgetUtil.isRamDay(k, ymd);
            for (int key : WidgetUtil.ALERT) {
                if (!a.forKey[key]) continue;
                if (key == PrayerCalc.IMSAK && !ram) continue;   // Imsak only matters in Ramadan
                long t = PrayerCalc.utcMs(ymd, s[key] - a.lead, k.tz);
                if (t > after && (best == null || t < best[0])) best = new long[]{t, key, a.lead, ymd[0], ymd[1], ymd[2], ram ? 1 : 0};
            }
            if (ram && a.wake > 0) {
                long t = PrayerCalc.utcMs(ymd, s[PrayerCalc.IMSAK] - a.wake, k.tz);
                if (t > after && (best == null || t < best[0])) best = new long[]{t, -1, a.wake, ymd[0], ymd[1], ymd[2], 1};
            }
        }
        return best;
    }

    static PendingIntent broadcast(Context c, int rc, Intent i) {
        int fl = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) fl |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, rc, i, fl);
    }

    static boolean exactAllowed(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    /** Sets an alarm that fires even in deep sleep; exact when Android allows it. */
    static void setAt(Context c, long t, PendingIntent p) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            if (!exactAllowed(c)) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
            else am.setExact(AlarmManager.RTC_WAKEUP, t, p);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
            else am.set(AlarmManager.RTC_WAKEUP, t, p);
        }
    }

    /** (Re)sets the next alert. Returns its time, or 0 when alerts are off. */
    static long schedule(Context c) {
        try {
            WidgetUtil.Cfg k = WidgetUtil.load(c);
            Alerts a = load(c);
            Intent i = new Intent(c, AlertReceiver.class).setAction(AlertReceiver.ALERT);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(broadcast(c, RC, i));
            if (!a.on) { prefs(c).edit().remove("nextAt").remove("nextTitle").apply(); return 0; }
            long[] n = next(k, a, System.currentTimeMillis() + 1000);
            if (n == null) { prefs(c).edit().remove("nextAt").apply(); return 0; }
            i.putExtra("at", n[0]).putExtra("key", (int) n[1]).putExtra("lead", (int) n[2])
             .putExtra("y", (int) n[3]).putExtra("m", (int) n[4]).putExtra("d", (int) n[5]).putExtra("ram", n[6] == 1);
            setAt(c, n[0], broadcast(c, RC, i));
            prefs(c).edit().putLong("nextAt", n[0]).putString("nextTitle", texts(c, i)[0]).apply();
            return n[0];
        } catch (Exception e) {
            return 0;
        }
    }

    /** A test alert in 5 seconds, using the same path as real alerts. */
    static void test(Context c) {
        Intent i = new Intent(c, AlertReceiver.class).setAction(AlertReceiver.TEST).putExtra("at", System.currentTimeMillis() + 5000);
        setAt(c, System.currentTimeMillis() + 5000, broadcast(c, RC_TEST, i));
    }

    static String pname(WidgetUtil.Cfg k, int key, boolean urdu) {
        boolean ui = WidgetUtil.urdu(k);
        return WidgetUtil.label(key, k, false, ui != urdu);
    }

    /** {title, body} worded exactly as the app words them */
    static String[] texts(Context c, Intent in) {
        WidgetUtil.Cfg k = WidgetUtil.load(c);
        boolean ur = WidgetUtil.urdu(k);
        if (AlertReceiver.TEST.equals(in.getAction())) {
            return new String[]{ur ? "\u0622\u0632\u0645\u0627\u0626\u0634\u06CC \u0627\u0644\u0631\u0679" : "Test alert",
                ur ? "\u0646\u0645\u0627\u0632 \u06A9\u06D2 \u0627\u0644\u0631\u0679 \u0627\u0633\u06CC \u0637\u0631\u062D \u0646\u0638\u0631 \u0622\u0626\u06CC\u06BA \u06AF\u06D2 \u0627\u0648\u0631 \u0633\u0646\u0627\u0626\u06CC \u062F\u06CC\u06BA \u06AF\u06D2\u06D4" : "This is how your prayer alerts will look and sound."};
        }
        int key = in.getIntExtra("key", PrayerCalc.MAGHRIB), lead = in.getIntExtra("lead", 0);
        boolean ram = in.getBooleanExtra("ram", false);
        int[] ymd = {in.getIntExtra("y", 2026), in.getIntExtra("m", 1), in.getIntExtra("d", 1)};
        int[] s = PrayerCalc.schedule(ymd, k.lat, k.lng, k.method, k.offsets, k.tz);
        String city = k.name;
        if (key < 0) {   // Sehri wake-up
            String t = WidgetUtil.join(WidgetUtil.fmt(s[PrayerCalc.IMSAK], k.h24, ur));
            return new String[]{ur ? "\u0633\u062D\u0631\u06CC \u06A9\u0627 \u0648\u0642\u062A" : "Time for Sehri",
                ur ? "\u0633\u062D\u0631\u06CC " + t + " \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648 \u06AF\u06CC\u060C " + city : "Sehri ends at " + t + ", " + city};
        }
        String en = pname(k, key, false), urn = pname(k, key, true), title;
        if (ram && lead == 0 && key == PrayerCalc.IMSAK) title = ur ? "\u0633\u062D\u0631\u06CC \u06A9\u0627 \u0648\u0642\u062A \u062E\u062A\u0645 \u06C1\u0648 \u06AF\u06CC\u0627" : "Sehri ends now";
        else if (ram && lead == 0 && key == PrayerCalc.MAGHRIB) title = ur ? "\u0627\u0641\u0637\u0627\u0631 \u06A9\u0627 \u0648\u0642\u062A \u06C1\u0648 \u06AF\u06CC\u0627" : "Iftar time";
        else if (lead > 0) title = ur ? urn + " \u0645\u06CC\u06BA " + lead + " \u0645\u0646\u0679 \u0628\u0627\u0642\u06CC" : en + " in " + lead + " minutes";
        else title = ur ? "\u0646\u0645\u0627\u0632\u0650 " + urn + " \u06A9\u0627 \u0648\u0642\u062A \u06C1\u0648 \u06AF\u06CC\u0627" : "It is time for " + en;
        String other = ur ? en : urn;
        return new String[]{title, other + "  " + WidgetUtil.join(WidgetUtil.fmt(s[key], k.h24, ur)) + "\u060C " + city};
    }

    /** Can this alert be marked as offered? (the five prayers, at their time) */
    static boolean prayable(Intent in) {
        if (!AlertReceiver.ALERT.equals(in.getAction()) || in.getIntExtra("lead", 0) != 0) return false;
        int key = in.getIntExtra("key", -1);
        return key == PrayerCalc.FAJR || key == PrayerCalc.DHUHR || key == PrayerCalc.ASR || key == PrayerCalc.MAGHRIB || key == PrayerCalc.ISHA;
    }
}

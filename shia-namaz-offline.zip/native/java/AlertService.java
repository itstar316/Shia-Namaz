package com.javediqbal.shianamaz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Plays the prayer alert sound itself, instead of leaving it to the notification system. Android stops a
 * notification's sound the moment the notification shade is opened; this player keeps going until the sound
 * ends or the user taps Stop. It respects silent and vibrate mode unless "play even on silent" is chosen.
 */
public class AlertService extends Service {
    static final String PLAY = "play", STOP = "stop";
    static final int NID = 7100;
    static final int NID_TONE = 7101;   // normal notifications use their own id, so they never replace a playing azan
    static final String CH = "prayer_alert", CH_FALLBACK = "prayer";
    static final String CH_TONE = "prayer_tone";   // normal notifications: the sound is the user's choice in Android settings
    static final long MAX_PLAY_MS = 10 * 60 * 1000L;  // the full azan (about 5½ minutes) always completes; a safety stop after 10

    static AlertService instance;
    private MediaPlayer mp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Intent last;
    private AudioManager am;
    private Object focus;

    @Override
    public IBinder onBind(Intent i) { return null; }

    static void stopNow() { if (instance != null) instance.finish(); }

    @Override
    public int onStartCommand(Intent in, int flags, int id) {
        instance = this;
        if (in == null || STOP.equals(in.getAction())) { finish(); return START_NOT_STICKY; }
        last = in;
        ensureChannels(this);
        Notification n = build(this, in, true, CH);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NID, n);
        } catch (Exception e) {
            notifyOnly(this, in);
            instance = null;
            stopSelf();
            return START_NOT_STICKY;
        }
        PrayerAlarm.Alerts a = PrayerAlarm.load(this);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        boolean ringerOn = am == null || am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
        if ((!a.silent && !ringerOn) || !play(a)) finish();   // silent or vibrate: the notification alone (it vibrates)
        return START_NOT_STICKY;
    }

    private Uri chime() { return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.chime); }
    private Uri azan() { return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.azan); }

    /** The azan is for the five prayers, on time. Sehri end, sunrise and early reminders keep a short tone. */
    static boolean useAzan(PrayerAlarm.Alerts a, Intent in) {
        if (!"azan".equals(a.style) || in == null) return false;
        if (AlertReceiver.TEST.equals(in.getAction()) || AlertReceiver.TEST.equals(in.getStringExtra("kind"))) return true;
        if (in.getIntExtra("lead", 0) != 0) return false;
        int k = in.getIntExtra("key", -1);
        return k == PrayerCalc.FAJR || k == PrayerCalc.DHUHR || k == PrayerCalc.ASR || k == PrayerCalc.MAGHRIB || k == PrayerCalc.ISHA;
    }

    static boolean playing() { return instance != null && instance.mp != null; }

    private boolean azanNow;

    private boolean play(PrayerAlarm.Alerts a) {
        azanNow = useAzan(a, last);
        try {
            stopPlayer();
            int usage = a.silent ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_NOTIFICATION_EVENT;
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            mp = new MediaPlayer();
            mp.setAudioAttributes(attrs);
            try {
                if (azanNow) mp.setDataSource(this, azan());
                else if (a.sound != null && a.sound.startsWith("/")) mp.setDataSource(a.sound);   // the app's own copy of the chosen sound
                else if (a.sound != null && !a.sound.isEmpty()) mp.setDataSource(this, Uri.parse(a.sound));
                else mp.setDataSource(this, chime());
            } catch (Exception e) {      // the chosen sound is gone (deleted file): fall back to the chime
                mp.reset();
                mp.setAudioAttributes(attrs);
                mp.setDataSource(this, chime());
            }
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setOnCompletionListener(p -> finish());
            mp.setOnErrorListener((p, w, x) -> { finish(); return true; });
            requestFocus(attrs);
            mp.prepare();
            mp.start();
            h.postDelayed(this::finish, MAX_PLAY_MS);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void requestFocus(AudioAttributes attrs) {
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AudioFocusRequest r = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).build();
                focus = r;
                am.requestAudioFocus(r);
            } else {
                am.requestAudioFocus(null, AudioManager.STREAM_NOTIFICATION, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) { }
    }

    private void abandonFocus() {
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && focus != null) am.abandonAudioFocusRequest((AudioFocusRequest) focus);
            else am.abandonAudioFocus(null);
        } catch (Exception ignored) { }
        focus = null;
    }

    private void stopPlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
    }

    /** Stops the sound and leaves the notification in place (without the Stop button). */
    void finish() {
        h.removeCallbacksAndMessages(null);
        stopPlayer();
        abandonFocus();
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_DETACH); else stopForeground(false);
            if (last != null) {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(NID, build(this, last, false, CH));
            }
        } catch (Exception ignored) { }
        instance = null;
        stopSelf();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        stopPlayer();
        abandonFocus();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        boolean ur = WidgetUtil.urdu(WidgetUtil.load(c));
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, ur ? "\u0646\u0645\u0627\u0632 \u06A9\u06D2 \u0627\u0644\u0631\u0679" : "Prayer alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);   // the sound is played by this service, so it is not cut off
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 400, 250, 400});
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_TONE) == null) {
            NotificationChannel t = new NotificationChannel(CH_TONE, ur ? "\u0646\u0645\u0627\u0632 \u06A9\u06CC \u0627\u0637\u0644\u0627\u0639" : "Prayer notifications", NotificationManager.IMPORTANCE_HIGH);
            t.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            t.enableVibration(true);
            t.setVibrationPattern(new long[]{0, 400, 250, 400});
            t.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(t);
        }
        if (nm.getNotificationChannel(CH_FALLBACK) == null) {
            NotificationChannel f = new NotificationChannel(CH_FALLBACK, ur ? "\u0646\u0645\u0627\u0632 \u06A9\u06D2 \u0627\u0648\u0642\u0627\u062A" : "Prayer times", NotificationManager.IMPORTANCE_HIGH);
            f.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.chime),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            f.enableVibration(true);
            nm.createNotificationChannel(f);
        }
    }

    static CharSequence bold(String s) {
        android.text.SpannableString sp = new android.text.SpannableString(s == null ? "" : s);
        sp.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, sp.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    static PendingIntent action(Context c, String act, Intent src, int rc) {
        Intent i = new Intent(c, AlertReceiver.class).setAction(act).putExtras(src);
        return PrayerAlarm.broadcast(c, rc, i);
    }

    @SuppressWarnings("deprecation")
    static Notification build(Context c, Intent in, boolean playing, String channel) {
        String[] t = PrayerAlarm.texts(c, in);
        boolean ur = WidgetUtil.urdu(WidgetUtil.load(c));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, channel) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_stat_notify).setColor(0xFFE0A93B).setContentTitle(bold(t[0])).setContentText(t[1])
         .setAutoCancel(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_REMINDER)
         .setVisibility(Notification.VISIBILITY_PUBLIC).setShowWhen(true).setWhen(in.getLongExtra("at", System.currentTimeMillis()));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (open != null) {
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            b.setContentIntent(PendingIntent.getActivity(c, 7110, open, fl));
        }
        if (CH.equals(channel)) b.setDeleteIntent(action(c, AlertReceiver.STOP, in, 7111));   // swiping the azan notification away stops the azan
        if (playing && Build.VERSION.SDK_INT >= 24) {
            // a large, clear Stop button (both languages) instead of the small text action
            PendingIntent stop = action(c, AlertReceiver.STOP, in, 7114);
            android.widget.RemoteViews small = new android.widget.RemoteViews(c.getPackageName(), R.layout.notif_azan_small);
            android.widget.RemoteViews big = new android.widget.RemoteViews(c.getPackageName(), R.layout.notif_azan);
            android.widget.RemoteViews hu = new android.widget.RemoteViews(c.getPackageName(), R.layout.notif_azan_hu);
            for (android.widget.RemoteViews v : new android.widget.RemoteViews[]{small, big, hu}) {
                v.setTextViewText(R.id.n_title, t[0]);
                v.setTextViewText(R.id.n_stop_main, ur ? "\u0627\u0630\u0627\u0646 \u0628\u0646\u062F \u06A9\u0631\u06CC\u06BA" : "Stop Azan");
                v.setOnClickPendingIntent(R.id.n_stop, stop);
            }
            big.setTextViewText(R.id.n_body, t[1]);
            big.setTextViewText(R.id.n_stop_other, ur ? "Stop" : "\u0628\u0646\u062F \u06A9\u0631\u06CC\u06BA");
            hu.setTextViewText(R.id.n_body, t[1]);
            b.setStyle(new Notification.DecoratedCustomViewStyle());
            b.setCustomContentView(small);
            b.setCustomBigContentView(big);
            b.setCustomHeadsUpContentView(hu);
        }
        if (playing && Build.VERSION.SDK_INT < 24) b.addAction(new Notification.Action.Builder(null, ur ? "\u0628\u0646\u062F \u06A9\u0631\u06CC\u06BA" : "Stop", action(c, AlertReceiver.STOP, in, 7112)).build());
        if (PrayerAlarm.prayable(in)) b.addAction(new Notification.Action.Builder(null, ur ? "\u0627\u062F\u0627 \u06A9\u0631 \u0644\u06CC \u2713" : "Prayed \u2713", action(c, AlertReceiver.PRAYED, in, 7113)).build());
        return b.build();
    }

    /** Shows the alert notification straight away (silent; the player then adds the sound and the Stop button). */
    static void notifyNow(Context c, Intent in) {
        try {
            ensureChannels(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(NID);   // a fresh notification for each prayer, so it vibrates once (updates afterwards stay quiet)
                nm.notify(NID, build(c, in, false, CH));
            }
        } catch (Exception ignored) { }
    }

    /** Normal notification: Android plays the sound chosen for the "Prayer notifications" channel. */
    static void notifyTone(Context c, Intent in) {
        try {
            ensureChannels(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) { nm.cancel(NID_TONE); nm.notify(NID_TONE, build(c, in, false, Build.VERSION.SDK_INT >= 26 ? CH_TONE : CH_FALLBACK)); }
        } catch (Exception ignored) { }
    }

    /** Fallback when the phone refuses to start the player: a normal notification that carries the chime itself. */
    static void notifyOnly(Context c, Intent in) {
        try {
            ensureChannels(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) { nm.cancel(NID); nm.notify(NID, build(c, in, false, CH_FALLBACK)); }
        } catch (Exception ignored) { }
    }
}

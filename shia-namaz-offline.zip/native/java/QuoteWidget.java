package com.javediqbal.shianamaz;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** Widget: a saying of Imam Ali (as) from Nahj al-Balagha, changing every day at midnight. */
public class QuoteWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        WidgetUtil.updateAll(context);
    }

    /** Called when the widget is resized: redraw it for its new size. */
    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        WidgetUtil.updateAll(context);
    }
}

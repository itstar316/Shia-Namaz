package com.javediqbal.shianamaz;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.ArrayList;

/**
 * Draws the same scene as the app's top card (b_sky.js): sky colours by the sun's height, the sun's path with the
 * prayer points, mountains, town and mosque (lit windows at night), the sun or the real moon, and the day's mood.
 * Coordinates are the app's: a 360 x 150 box, horizon at y = 104.
 */
final class SkyRenderer {
    private SkyRenderer() { }

    static final double RAD = Math.PI / 180;
    static final float W = 360, H = 150, CX = 180, CY = 104, RX = 150, RY = 82, B = 104;

    // ---------- colours (same tables as the app) ----------
    static final Object[][] SKY = {
        {-90.0, "#070B22", "#121A44"}, {-18.0, "#0A0F2C", "#1B2253"}, {-12.0, "#141A45", "#3A2F66"}, {-6.0, "#1E2558", "#7A3F62"},
        {-3.0, "#283171", "#B5493E"}, {0.0, "#33418A", "#E0784A"}, {6.0, "#3F5FAE", "#EDB46C"}, {15.0, "#2F63B3", "#9CC3E6"}, {90.0, "#1F56A8", "#7FB2E2"}};
    static final Object[][] LAND = {
        {-90.0, "#141A40", "#10153A", "#0C1030", "#4A5585", .45, "#080B22"}, {-12.0, "#1C2350", "#161C46", "#111637", "#5E6A9A", .55, "#0B0E26"},
        {-5.0, "#3B2E5E", "#2E2550", "#231C42", "#C99BBE", .8, "#191433"}, {0.0, "#7A5A8C", "#5B4272", "#3F2E58", "#FFC4A3", .95, "#251D3B"},
        {5.0, "#8C86B2", "#636C9E", "#4A5585", "#FFE3CC", 1.0, "#2B4646"}, {14.0, "#9CB3D6", "#6F8DBA", "#4E6C9C", "#FFFFFF", 1.0, "#2C5848"},
        {90.0, "#A4BCDF", "#7593C0", "#5272A2", "#FFFFFF", 1.0, "#2E5C4B"}};

    static int hex(String h) { return Color.parseColor(h); }
    static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }
    static int alpha(int c, double a) { return (Math.max(0, Math.min(255, (int) Math.round(a * 255))) << 24) | (c & 0xFFFFFF); }

    /** mood tints: [sky top, sky horizon, amount, land, land amount] — same as MOOD in the app */
    static Object[] moodTint(String mood) {
        if (mood == null) return null;
        switch (mood) {
            case "ashura": return new Object[]{"#0E0306", "#4E0B12", .82, "#12060A", .62};
            case "aza": case "sad": return new Object[]{"#18050A", "#6A141B", .78, "#1A090D", .55};
            case "joy": return new Object[]{"#1F56A8", "#F2C66D", .18, null, 0.0};
            case "eid": return new Object[]{"#1E4FA0", "#F6CF73", .26, null, 0.0};
            case "ramadan": return new Object[]{"#140F3A", "#3E2E6E", .42, "#120E2C", .22};
            default: return null;
        }
    }

    static int[] skyColors(double alt, String mood) {
        int top = hex((String) SKY[8][1]), hor = hex((String) SKY[8][2]);
        for (int i = 1; i < SKY.length; i++) {
            double a0 = (Double) SKY[i - 1][0], a1 = (Double) SKY[i][0];
            if (alt <= a1) {
                double t = (alt - a0) / (a1 - a0);
                top = mix(hex((String) SKY[i - 1][1]), hex((String) SKY[i][1]), t);
                hor = mix(hex((String) SKY[i - 1][2]), hex((String) SKY[i][2]), t);
                break;
            }
        }
        Object[] m = moodTint(mood);
        if (m != null) { top = mix(top, hex((String) m[0]), (Double) m[2]); hor = mix(hor, hex((String) m[1]), (Double) m[2]); }
        return new int[]{top, hor};
    }

    static final class Pal { int far, mid, near, snow, tree; double snowOp; }

    static Pal landPal(double alt, String mood) {
        Object[] a = LAND[0], b = LAND[LAND.length - 1];
        double t = 0;
        for (int i = 1; i < LAND.length; i++) {
            if (alt <= (Double) LAND[i][0]) { a = LAND[i - 1]; b = LAND[i]; t = (alt - (Double) a[0]) / ((Double) b[0] - (Double) a[0]); break; }
        }
        Object[] m = moodTint(mood);
        Pal p = new Pal();
        int[] c = new int[7];
        for (int k : new int[]{1, 2, 3, 4, 6}) {
            int v = mix(hex((String) a[k]), hex((String) b[k]), t);
            if (m != null && m[3] != null) v = mix(v, hex((String) m[3]), (Double) m[4]);
            c[k] = v;
        }
        p.far = c[1]; p.mid = c[2]; p.near = c[3]; p.snow = c[4]; p.tree = c[6];
        p.snowOp = (Double) a[5] + ((Double) b[5] - (Double) a[5]) * Math.max(0, Math.min(1, t));
        return p;
    }

    // ---------- sun and moon ----------
    static double jd(long utcMs) { return utcMs / 86400000.0 + 2440587.5; }

    static double sunAltitude(long utcMs, double lat, double lng) {
        double j = jd(utcMs);
        double[] sp = PrayerCalc.sunPos(j);
        double dec = sp[0], eqt = sp[1];
        double ut = ((utcMs / 3600000.0) % 24 + 24) % 24;
        double ha = 15 * (ut + lng / 15.0 + eqt - 12);
        double s = Math.sin(lat * RAD) * Math.sin(dec * RAD) + Math.cos(lat * RAD) * Math.cos(dec * RAD) * Math.cos(ha * RAD);
        return Math.asin(Math.max(-1, Math.min(1, s))) / RAD;
    }

    /** {altitude, illuminated fraction, waxing ? 1 : 0} — the same low-precision formulas as the app */
    static double[] moon(long utcMs, double lat, double lng) {
        double d = jd(utcMs) - 2451545.0;
        double L = 218.316 + 13.176396 * d, M = 134.963 + 13.064993 * d, F = 93.272 + 13.229350 * d;
        double lam = (L + 6.289 * Math.sin(M * RAD)) * RAD, bet = 5.128 * Math.sin(F * RAD) * RAD, eps = (23.439 - 4e-7 * d) * RAD;
        double ra = Math.atan2(Math.sin(lam) * Math.cos(eps) - Math.tan(bet) * Math.sin(eps), Math.cos(lam));
        double dec = Math.asin(Math.sin(bet) * Math.cos(eps) + Math.cos(bet) * Math.sin(eps) * Math.sin(lam));
        double lst = (280.46061837 + 360.98564736629 * d + lng) * RAD, ha = lst - ra, phi = lat * RAD;
        double alt = Math.asin(Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(ha)) / RAD;
        double g = (357.528 + 0.9856003 * d) * RAD, ls = (280.46 + 0.9856474 * d + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) * RAD;
        double e = ((lam - ls) / RAD) % 360; if (e < 0) e += 360;
        return new double[]{alt - 0.95 * Math.cos(alt * RAD), (1 - Math.cos(e * RAD)) / 2, e < 180 ? 1 : 0};
    }

    /** 0 at moonrise … 1 at moonset, or -1 when the moon is below the horizon */
    static double moonPass(long now, double lat, double lng) {
        if (moon(now, lat, lng)[0] <= -0.3) return -1;
        long step = 6 * 60000L, a = now, b = now;
        for (int i = 0; i < 300 && moon(a - step, lat, lng)[0] > -0.3; i++) a -= step;
        for (int i = 0; i < 300 && moon(b + step, lat, lng)[0] > -0.3; i++) b += step;
        return Math.max(0, Math.min(1, (now - a) / (double) Math.max(1, b - a)));
    }

    // ---------- fixed scenery: pines and the town (same seeds as the app, so it looks identical) ----------
    static final ArrayList<float[]> PINES = new ArrayList<>(), BLOCKS = new ArrayList<>(), WINS = new ArrayList<>();
    static {
        long[] seed = {11};
        double x = 72;
        while (x < 296) {
            double h = 5 + rnd(seed) * 7, w = h * .42;
            PINES.add(new float[]{(float) x, (float) h, (float) w});
            x += w * 1.3 + rnd(seed) * 5 + (x > 150 && x < 180 ? 6 : 0);
        }
        long[] s2 = {29};
        town(s2, 70, 103, 6, 14);
        town(s2, 150, 196, 7, 17);
        town(s2, 232, 292, 6, 15);
    }
    static double rnd(long[] s) { s[0] = (s[0] * 16807L) % 2147483647L; return s[0] / 2147483647.0; }
    static void town(long[] s, double x0, double x1, double hmin, double hmax) {
        double x = x0;
        while (x < x1) {
            double w = 5 + rnd(s) * 6.5, h = hmin + rnd(s) * (hmax - hmin);
            if (x + w > x1) break;
            BLOCKS.add(new float[]{(float) x, (float) w, (float) h});
            for (double wy = B - h + 2.2; wy < B - 2.2; wy += 3.1)
                for (double wx = x + 1.3; wx < x + w - 1.6; wx += 2.6) WINS.add(new float[]{(float) wx, (float) wy, (float) rnd(s)});
            x += w + (rnd(s) < .35 ? 1.2 + rnd(s) * 2 : 0.15);
        }
    }

    // ---------- tiny path helper for the app's path strings (M, L, Q, T, Z only) ----------
    static Path path(String d) {
        Path p = new Path();
        String[] t = d.replace(",", " ").trim().split("\\s+|(?=[MLQTZ])|(?<=[MLQTZ])");
        ArrayList<String> tok = new ArrayList<>();
        for (String x : t) if (!x.isEmpty()) tok.add(x);
        float lx = 0, ly = 0, qx = 0, qy = 0;
        char cmd = 'M';
        int i = 0;
        while (i < tok.size()) {
            String s = tok.get(i);
            if (s.length() == 1 && "MLQTZ".indexOf(s.charAt(0)) >= 0) { cmd = s.charAt(0); i++; if (cmd == 'Z') { p.close(); } continue; }
            switch (cmd) {
                case 'M': lx = f(tok, i); ly = f(tok, i + 1); p.moveTo(lx, ly); i += 2; cmd = 'L'; qx = lx; qy = ly; break;
                case 'L': lx = f(tok, i); ly = f(tok, i + 1); p.lineTo(lx, ly); i += 2; qx = lx; qy = ly; break;
                case 'Q': qx = f(tok, i); qy = f(tok, i + 1); lx = f(tok, i + 2); ly = f(tok, i + 3); p.quadTo(qx, qy, lx, ly); i += 4; break;
                case 'T': { float cx = 2 * lx - qx, cy = 2 * ly - qy; float x = f(tok, i), y = f(tok, i + 1); p.quadTo(cx, cy, x, y); qx = cx; qy = cy; lx = x; ly = y; i += 2; break; }
                default: i++;
            }
        }
        return p;
    }
    static float f(ArrayList<String> t, int i) { return Float.parseFloat(t.get(i)); }

    static Paint fill(int c) { Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setStyle(Paint.Style.FILL); p.setColor(c); return p; }
    static Paint stroke(int c, float w) { Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setStyle(Paint.Style.STROKE); p.setColor(c); p.setStrokeWidth(w); return p; }

    /** Background of the whole card: sky gradient, stars at night, and the mood decoration along the top. */
    static Bitmap background(int wPx, int hPx, float radiusPx, double alt, String mood, float density) {
        Bitmap bm = Bitmap.createBitmap(Math.max(8, wPx), Math.max(8, hPx), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        int[] sk = skyColors(alt, mood);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, hPx, sk[0], sk[1], Shader.TileMode.CLAMP));
        RectF r = new RectF(0, 0, wPx, hPx);
        c.drawRoundRect(r, radiusPx, radiusPx, p);
        // stars, fading in with darkness
        double dark = alt < -12 ? 1 : alt < -3 ? (-3 - alt) / 9 : 0;
        if (dark > 0) {
            long[] seed = {7};
            Paint sp = fill(Color.WHITE);
            for (int i = 0; i < 46; i++) {
                float x = (float) (rnd(seed) * wPx), y = (float) (rnd(seed) * .62 * hPx), rr = (float) ((rnd(seed) * 1.1 + .35) * density * .9);
                sp.setColor(alpha(Color.WHITE, (rnd(seed) * .6 + .3) * dark));
                c.drawCircle(x, y, rr, sp);
            }
        }
        if (mood != null && (mood.equals("ashura") || mood.equals("aza") || mood.equals("sad"))) {
            // black mourning drape (jhalar) along the top edge
            c.save();
            Path clip = new Path(); clip.addRoundRect(r, radiusPx, radiusPx, Path.Direction.CW); c.clipPath(clip);
            float dh = 14 * density, n = 18;
            Path d = new Path(); d.moveTo(0, 0); d.lineTo(wPx, 0); d.lineTo(wPx, dh * .3f);
            for (int i = (int) n; i > 0; i--) { float x0 = i * wPx / n, x1 = (i - 1) * wPx / n; d.quadTo((x0 + x1) / 2, dh, x1, dh * .3f); }
            d.close();
            c.drawPath(d, fill(alpha(0x07070A, .92)));
            c.restore();
        } else if (mood != null && (mood.equals("eid") || mood.equals("joy"))) {
            int[] cols = {0xFF2E9E6A, 0xFFF2C14E, 0xFFFFFFFF, 0xFFE86A5A, 0xFF5BA8E8};
            int n = 14; float fh = 12 * density;
            for (int i = 0; i < n; i++) {
                float x = i * wPx / (float) n + 2 * density, w = wPx / (float) n - 4 * density;
                float y = (float) (3 * density + Math.sin(i / (double) (n - 1) * Math.PI) * 5 * density);
                Path t = new Path(); t.moveTo(x, y); t.lineTo(x + w, y); t.lineTo(x + w / 2, y + fh); t.close();
                c.drawPath(t, fill(alpha(cols[i % cols.length], .92)));
            }
        }
        return bm;
    }

    /**
     * The scene: arc, prayer points, landscape, town, sun/moon. Transparent around it.
     * tm/yd/nx are the prayer minutes of today, yesterday, tomorrow; nowMin is minutes since local midnight.
     */
    static Bitmap scene(int wPx, double alt, String mood, int hijriMonth, int[] tm, int[] yd, int[] nx, int nowMin,
                        long nowMs, double lat, double lng, String[] names, boolean ur) {
        float s = wPx / W;
        int hPx = Math.round(H * s);
        Bitmap bm = Bitmap.createBitmap(Math.max(8, wPx), Math.max(8, hPx), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        c.scale(s, s);

        int sr = tm[PrayerCalc.SUNRISE], ss = tm[PrayerCalc.SUNSET];
        boolean before = nowMin < sr;
        double ns = before ? yd[PrayerCalc.SUNSET] - 1440 : ss, ne = before ? sr : nx[PrayerCalc.SUNRISE] + 1440;
        int[] mor = before ? tm : nx; int mbase = before ? 0 : 1440;
        int[] src = before ? yd : tm; int base = before ? -1440 : 0;
        boolean isDay = nowMin >= sr && nowMin <= ss;

        // sun's path (upper half), the night path (dotted, lower) and the horizon
        RectF top = new RectF(CX - RX, CY - RY, CX + RX, CY + RY);
        c.drawArc(top, 180, 180, false, stroke(alpha(Color.WHITE, .42), 1.1f));
        Paint dot = fill(alpha(Color.WHITE, .38));
        for (int i = 0; i <= 40; i++) { double a = -Math.PI * i / 40.0; c.drawCircle((float) (CX + RX * Math.cos(a)), (float) (CY - RY * .55 * Math.sin(a)), .9f, dot); }
        c.drawLine(6, CY, W - 6, CY, stroke(alpha(Color.WHITE, .5), 1f));

        // the real moon on the same path
        double mp = moonPass(nowMs, lat, lng);
        if (mp >= 0) {
            double a = Math.PI * (1 - mp);
            drawMoon(c, (float) (CX + RX * Math.cos(a)), (float) (CY - RY * Math.sin(a)), 9, moon(nowMs, lat, lng), isDay);
        }

        // landscape
        Pal p = landPal(alt, mood);
        Paint far = fill(alpha(p.far, .85));
        c.drawPath(path("M58 104 L74 95 L86 98 L100 89 L114 93 L126 84 L140 90 L156 86 L170 91 L232 90 L248 85 L262 91 L276 88 L290 95 L304 104 Z"), far);
        c.drawPath(path("M86 104 L104 92 L118 82 L130 68 L139 75 L146 79 L156 88 L166 104 Z"), fill(p.mid));
        c.drawPath(path("M130 68 L139 75 L136 76 L132 73 L128 75 L126 73 Z"), fill(alpha(p.snow, p.snowOp)));
        c.drawPath(path("M236 104 L250 93 L262 86 L271 80 L280 88 L292 96 L300 104 Z"), fill(p.mid));
        c.drawPath(path("M150 104 L168 88 L181 81 L193 65 L204 50 L213 61 L221 70 L234 82 L250 92 L266 104 Z"), fill(p.near));
        c.drawPath(path("M204 50 L213 61 L221 70 L234 82 L250 92 L266 104 L212 104 L207 74 Z"), fill(alpha(Color.BLACK, .16)));
        c.drawPath(path("M204 50 L213 61 L217 66 L211 65 L208 69 L204 63 L200 68 L197 62 L193 65 Z"), fill(alpha(p.snow, p.snowOp)));
        Paint streak = stroke(alpha(p.snow, p.snowOp * .55), .8f);
        c.drawLine(193, 65, 190, 72, streak); c.drawLine(200, 68, 198, 76, streak); c.drawLine(213, 61, 219, 71, streak);
        c.drawPath(path("M168 88 L181 81 L193 65 L204 50"), stroke(alpha(p.snow, p.snowOp * .25), .7f));
        c.drawPath(path("M66 104 Q120 97 182 100 T300 104 Z"), fill(alpha(p.tree, .9)));
        Paint tree = fill(p.tree);
        for (float[] pn : PINES) {
            float x = pn[0], h = pn[1], w = pn[2];
            if ((x > 68 && x < 106) || (x > 107 && x < 145) || (x > 148 && x < 198) || (x > 230 && x < 294)) continue;
            Path t = new Path();
            t.moveTo(x - w, B); t.lineTo(x, B - h); t.lineTo(x + w, B); t.close();
            t.moveTo(x - w * .75f, B - h * .45f); t.lineTo(x, B - h * 1.12f); t.lineTo(x + w * .75f, B - h * .45f); t.close();
            c.drawPath(t, tree);
        }
        drawTown(c, alt, p, mood, hijriMonth);

        // prayer points and their names
        float[][] pts = new float[6][];
        int[] keys = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
        pts[0] = nightPt(mor[PrayerCalc.FAJR] + mbase, ns, ne);
        pts[1] = dayPt(sr, sr, ss); pts[2] = dayPt(tm[PrayerCalc.DHUHR], sr, ss); pts[3] = dayPt(tm[PrayerCalc.ASR], sr, ss);
        pts[4] = nightPt(src[PrayerCalc.MAGHRIB] + base, ns, ne); pts[5] = nightPt(src[PrayerCalc.ISHA] + base, ns, ne);
        String[] pos = {"below", "horizon", "above", "above", "below", "below"};
        float[] sp = isDay ? dayPt(nowMin, sr, ss) : nightPt(nowMin, ns, ne);
        Paint pd = fill(alpha(Color.WHITE, .85));
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(alpha(Color.WHITE, .8)); tp.setTextSize(ur ? 12 : 11); tp.setTypeface(Typeface.DEFAULT);
        for (int i = 0; i < 6; i++) {
            float x = pts[i][0], y = pts[i][1];
            c.drawCircle(x, y, 3, pd);
            if (Math.hypot(x - sp[0], y - sp[1]) < 30) continue;
            String lab = names[i];
            float lx = x, ly = pos[i].equals("below") ? y + 18 : y - 12;
            Paint.Align al = Paint.Align.CENTER;
            if (keys[i] == PrayerCalc.MAGHRIB) { lx = x - 9; ly = y + 4; al = Paint.Align.RIGHT; }
            tp.setTextAlign(al);
            c.drawText(lab, lx, ly, tp);
        }

        // the sun by day; a small "now" dot at night
        if (isDay) drawSun(c, sp[0], sp[1], alt, mood);
        else {   // the sun below the horizon: a small dim grey-lavender sun with rays, unlike the white prayer dots
            c.drawCircle(sp[0], sp[1], 12, fill(alpha(0x8E98C8, .14)));
            Paint ray = stroke(alpha(0xA9B1D6, .75), 1.2f);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                c.drawLine((float) (sp[0] + 6.2 * Math.cos(a)), (float) (sp[1] + 6.2 * Math.sin(a)), (float) (sp[0] + 8.6 * Math.cos(a)), (float) (sp[1] + 8.6 * Math.sin(a)), ray);
            }
            c.drawCircle(sp[0], sp[1], 4.3f, fill(alpha(0xA9B1D6, .9)));
        }
        return bm;
    }

    static float[] dayPt(double m, double sr, double ss) {
        double t = (m - sr) / (ss - sr), a = Math.PI * (1 - t);
        return new float[]{(float) (CX + RX * Math.cos(a)), (float) (CY - RY * Math.sin(a))};
    }
    static float[] nightPt(double m, double s, double e) {
        double t = (m - s) / (e - s), a = -Math.PI * t;
        return new float[]{(float) (CX + RX * Math.cos(a)), (float) (CY - RY * .55 * Math.sin(a))};
    }

    static void drawSun(Canvas c, float x, float y, double alt, String mood) {
        double lo = Math.max(0, Math.min(1, 1 - alt / 14));
        boolean red = mood != null && (mood.equals("ashura") || mood.equals("aza") || mood.equals("sad"));
        int core = red ? 0xFFE39183 : 0xFFFFFBEA;
        int mid = red ? 0xFFC65A4E : mix(0xFFFFD65C, 0xFFFF9A4D, lo);
        int edge = red ? 0xFFC65A4E : mix(0xFFFFB347, 0xFFF2603A, lo);
        float r = 10, gr = (float) (r * (3.4 + 1.6 * lo));
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(x, y, gr, new int[]{alpha(mid, .55 + .2 * lo), alpha(mid, .22 + .15 * lo), alpha(edge, 0)},
            new float[]{0, .35f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, gr, g);
        c.drawCircle(x, y, r * 1.35f, fill(alpha(mid, .35)));
        Paint b = new Paint(Paint.ANTI_ALIAS_FLAG);
        b.setShader(new RadialGradient(x, y, r, new int[]{core, core, mid, edge}, new float[]{0, .55f, .85f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, b);
    }

    static void drawMoon(Canvas c, float x, float y, float r, double[] st, boolean dim) {
        double k = st[1];
        if (k < 0.015) return;
        boolean waxing = st[2] > 0;
        float erx = (float) (r * Math.abs(1 - 2 * k));
        RectF o = new RectF(x - r, y - r, x + r, y + r), oe = new RectF(x - erx, y - r, x + erx, y + r);
        Path lit = new Path();
        lit.moveTo(x, y - r);
        if (waxing) { lit.arcTo(o, -90, 180); lit.arcTo(oe, 90, k < .5 ? -180 : 180); }
        else { lit.arcTo(o, -90, -180); lit.arcTo(oe, 90, k < .5 ? 180 : -180); }
        lit.close();
        float op = dim ? .78f : 1f;
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        double ga = dim ? .05 : .08 + .14 * k;
        g.setShader(new RadialGradient(x, y, r * 3.2f, new int[]{alpha(0xE8ECFF, ga * 1.6 * op), alpha(0xC9D3FF, ga * op), alpha(0xC9D3FF, 0)},
            new float[]{0, .45f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r * 3.2f, g);
        if (!dim) c.drawCircle(x, y, r, fill(alpha(0x3A4468, .28)));
        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setShader(new RadialGradient(x - r * .16f, y - r * .24f, r * 1.4f, new int[]{alpha(0xFBFAF4, op), alpha(0xECE8DA, op), alpha(0xCFC9B8, op)},
            new float[]{0, .7f, 1}, Shader.TileMode.CLAMP));
        c.drawPath(lit, body);
        c.save();
        c.clipPath(lit);
        Paint mare = fill(alpha(0x9C978A, .38 * op));
        float[][] M = {{-.28f, -.38f, .30f, .24f}, {.18f, -.42f, .20f, .17f}, {.36f, -.08f, .24f, .19f}, {.55f, .18f, .14f, .17f},
            {-.48f, .12f, .30f, .36f}, {-.10f, .40f, .22f, .14f}, {.12f, .10f, .10f, .08f}, {-.05f, -.12f, .14f, .10f}};
        for (float[] m : M) c.drawOval(new RectF(x + (m[0] - m[2]) * r, y + (m[1] - m[3]) * r, x + (m[0] + m[2]) * r, y + (m[1] + m[3]) * r), mare);
        c.restore();
    }

    static void drawTown(Canvas c, double alt, Pal p, String mood, int hijriMonth) {
        double on = alt < -3 ? 1 : alt < 5 ? (5 - alt) / 8 : 0;
        int body = mix(p.near, p.tree, .45), edge = mix(p.far, p.near, .5);
        if (on > 0) c.drawRect(66, 92, 296, 104, fill(alpha(0xFFC86B, .05 * on)));
        Paint bp = fill(body), ep = fill(alpha(edge, .8));
        for (float[] bl : BLOCKS) {
            c.drawRect(bl[0], B - bl[2], bl[0] + bl[1], B, bp);
            c.drawRect(bl[0], B - bl[2], bl[0] + bl[1], B - bl[2] + .7f, ep);
        }
        Paint wp = fill(0);
        for (float[] w : WINS) {
            boolean lit = w[2] < .6 && on > 0;
            double o = lit ? Math.min(1, (.75 + .4 * w[2]) * on) : .08 * (1 - on) + .03;
            if (o <= .02) continue;
            wp.setColor(alpha(lit ? 0xFFD98A : 0xFFFFFF, o));
            c.drawRect(w[0], w[1], w[0] + 1.25f, w[1] + 1.55f, wp);
        }
        // mosque
        float mx = 126, mw = 24, mh = 7;
        c.drawRect(mx - mw / 2, B - mh, mx + mw / 2, B, bp);
        c.drawArc(new RectF(mx - 7.5f, B - mh - 7.5f, mx + 7.5f, B - mh + 7.5f), 180, 180, true, bp);
        c.drawRect(mx - .35f, B - mh - 11, mx + .35f, B - mh - 7.4f, bp);
        for (float side : new float[]{-1, 1}) {
            float x0 = side < 0 ? mx - mw / 2 - 3.2f : mx + mw / 2 + .6f;
            c.drawRect(x0, B - 22, x0 + 2.6f, B, bp);
            Path cap = new Path(); cap.moveTo(x0 - .2f, B - 22); cap.lineTo(x0 + 1.3f, B - 25.5f); cap.lineTo(x0 + 2.8f, B - 22); cap.close();
            c.drawPath(cap, bp);
            c.drawRect(x0 - .6f, B - 16, x0 + 3.2f, B - 15, bp);
        }
        // crescent on the dome
        Path cr = new Path(); cr.addCircle(mx - .3f, B - mh - 12.2f, 1.7f, Path.Direction.CW);
        Path cut = new Path(); cut.addCircle(mx + .5f, B - mh - 12.6f, 1.4f, Path.Direction.CW);
        cr.op(cut, Path.Op.DIFFERENCE);
        c.drawPath(cr, fill(alpha(on > .3 ? 0xFFE3A0 : edge, .95)));
        // arched windows
        Paint aw = fill(alpha(on > 0 ? 0xFFD98A : 0xFFFFFF, on > 0 ? .85 * on : .10));
        for (int dx = -8; dx <= 8; dx += 4) c.drawRoundRect(new RectF(mx + dx - 1, B - 4, mx + dx + 1, B - 1), 1, 1, aw);
        // Ramadan: small golden lights on the dome and minarets
        if ("ramadan".equals(mood)) {
            Paint lp = fill(0xFFFFE29A);
            for (int i = 0; i <= 10; i++) { double a = Math.PI * (1 - i / 10.0); c.drawCircle((float) (mx + 7.9 * Math.cos(a)), (float) (B - mh - 7.9 * Math.sin(a)), .75f, lp); }
            for (float y = B - 21; y < B - 1; y += 2.4f) { c.drawCircle(mx - mw / 2 - 1.9f, y, .7f, lp); c.drawCircle(mx + mw / 2 + 1.9f, y, .7f, lp); }
        }
        // Muharram: a small red flag on the right minaret
        if (hijriMonth == 1) {
            float x = 139.9f, t = 78.5f;
            c.drawLine(x, t, x, t - 8.6f, stroke(0xFF2A1A12, .8f));
            c.drawCircle(x, t - 8.9f, .7f, fill(0xFFD4AF55));
            c.drawPath(path("M" + (x + .3f) + " " + (t - 8) + " Q" + (x + 3.5f) + " " + (t - 9) + " " + (x + 7) + " " + (t - 7.8f)
                + " Q" + (x + 5.6f) + " " + (t - 6.2f) + " " + (x + 7) + " " + (t - 4.6f) + " Q" + (x + 3.5f) + " " + (t - 5.8f) + " " + (x + .3f) + " " + (t - 4.8f) + " Z"),
                fill(0xFFC0141E));
        }
    }
}

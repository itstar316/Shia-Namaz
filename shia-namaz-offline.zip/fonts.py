# Downloads the Google Fonts used by the app into www/fonts so the APK works fully offline.
import re, sys, os, hashlib, urllib.request
www = sys.argv[1]
html = open(os.path.join(www, 'index.html'), encoding='utf-8').read()
m = re.search(r'<link href="(https://fonts\.googleapis\.com/css2[^"]+)" rel="stylesheet">', html)
if not m:
    sys.exit('fonts.py: no Google Fonts link found')
ua = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36'
css = urllib.request.urlopen(urllib.request.Request(m.group(1).replace('&amp;', '&'), headers={'User-Agent': ua}), timeout=60).read().decode()
os.makedirs(os.path.join(www, 'fonts'), exist_ok=True)
count = 0
def grab(mm):
    global count
    url = mm.group(1)
    name = hashlib.md5(url.encode()).hexdigest()[:14] + '.woff2'
    data = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': ua}), timeout=60).read()
    open(os.path.join(www, 'fonts', name), 'wb').write(data)
    count += 1
    return 'url(' + name + ')'
css = re.sub(r'url\((https://fonts\.gstatic\.com/[^)]+)\)', grab, css)
open(os.path.join(www, 'fonts', 'fonts.css'), 'w', encoding='utf-8').write(css)
html = html.replace(m.group(0), '<link href="fonts/fonts.css" rel="stylesheet">')
html = re.sub(r'<link rel="preconnect"[^>]*>', '', html)
open(os.path.join(www, 'index.html'), 'w', encoding='utf-8').write(html)
print('fonts.py: bundled', count, 'font files')

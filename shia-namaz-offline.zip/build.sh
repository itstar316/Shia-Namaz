#!/usr/bin/env bash
# Builds the fully offline Shia Namaz APK (Capacitor 6). Run by GitHub Actions.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
OUT="$(pwd)"
KS_PASS="${KS_PASS:-}"
if [ -z "$KS_PASS" ]; then echo "ERROR: add the KS_PASS secret in Settings > Secrets and variables > Actions"; exit 1; fi
APP_ID="com.javediqbal.shianamaz"

rm -rf "$OUT/build" && mkdir -p "$OUT/build" && cd "$OUT/build"
cp -r "$SRC/www" ./www

echo "== Bundling fonts for offline use"
python3 "$SRC/fonts.py" www || echo "Fonts could not be downloaded; the app will use the phone's built-in fonts."

echo "== Installing Capacitor"
cat > package.json <<'JSON'
{ "name": "shia-namaz", "version": "1.0.0", "private": true,
  "dependencies": {
    "@capacitor/android": "^6.0.0", "@capacitor/app": "^6.0.0", "@capacitor/cli": "^6.0.0",
    "@capacitor/core": "^6.0.0", "@capacitor/local-notifications": "^6.0.0" } }
JSON
cat > capacitor.config.json <<JSON
{ "appId": "$APP_ID", "appName": "Shia Namaz", "webDir": "www",
  "android": { "backgroundColor": "#0C1029" },
  "plugins": { "LocalNotifications": { "smallIcon": "ic_stat_notify", "iconColor": "#E0A93B", "sound": "chime.wav" } } }
JSON
npm install --no-audit --no-fund
npx cap add android

echo "== Applying icons, splash, colours and sound"
RES=android/app/src/main/res
find "$RES" -name 'splash.png' -delete
rm -f "$RES"/mipmap-anydpi-v26/*.xml
cp -r "$SRC/native/res/." "$RES/"

echo "== Permissions and portrait mode"
MAN=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n    <uses-permission android:name="android.permission.VIBRATE" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <application#' "$MAN"
sed -i 's#android:name=".MainActivity"#android:name=".MainActivity"\n            android:screenOrientation="portrait"#' "$MAN"

echo "== Signing and version"
cp "$SRC/release.jks" android/app/release.jks
cat >> android/app/build.gradle <<GRADLE

android {
    defaultConfig {
        versionCode((System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInteger())
        versionName("1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "1"))
    }
    signingConfigs {
        release {
            storeFile file("release.jks")
            storePassword "$KS_PASS"
            keyAlias "shianamaz"
            keyPassword "$KS_PASS"
        }
    }
    buildTypes { release { signingConfig signingConfigs.release; minifyEnabled false } }
    lint { abortOnError false; checkReleaseBuilds false }
}
GRADLE

npx cap sync android

echo "== Building APK"
cd android && chmod +x gradlew && ./gradlew assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk "$OUT/ShiaNamaz.apk"
echo "== Done: ShiaNamaz.apk"

#!/usr/bin/env bash
# Builds the fully offline Waqt-e-Sehr APK (Capacitor 6). Run by GitHub Actions.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
OUT="$(pwd)"
KS_PASS="${KS_PASS:-}"
if [ -z "$KS_PASS" ]; then echo "ERROR: the KS_PASS secret is missing (add it in Codemagic environment variables)"; exit 1; fi
APP_ID="com.javediqbal.shianamaz"

rm -rf "$OUT/build" && mkdir -p "$OUT/build" && cd "$OUT/build"
cp -r "$SRC/www" ./www

echo "== Bundling fonts for offline use"
python3 "$SRC/fonts.py" www || echo "Fonts could not be downloaded; the app will use the phone's built-in fonts."

echo "== Installing Capacitor"
cat > package.json <<'JSON'
{ "name": "shia-namaz", "version": "1.0.0", "private": true,
  "dependencies": {
    "@capacitor/android": "^6.0.0", "@capacitor/app": "^6.0.0", "@capacitor/cli": "^6.0.0",
    "@capacitor/core": "^6.0.0", "@capacitor/local-notifications": "^6.0.0" } }
JSON
cat > capacitor.config.json <<JSON
{ "appId": "$APP_ID", "appName": "Waqt-e-Sehr", "webDir": "www",
  "android": { "backgroundColor": "#0C1029" },
  "plugins": { "LocalNotifications": { "smallIcon": "ic_stat_notify", "iconColor": "#E0A93B", "sound": "chime.wav" } } }
JSON
npm install --no-audit --no-fund
# The page needs Capacitor's JavaScript bridge to reach Android (notifications, widgets)
cp node_modules/@capacitor/core/dist/capacitor.js www/capacitor.js
npx cap add android

echo "== Applying icons, splash, colours and sound"
RES=android/app/src/main/res
find "$RES" -name 'splash.png' -delete
rm -f "$RES"/mipmap-anydpi-v26/*.xml
cp -r "$SRC/native/res/." "$RES/"

echo "== Widgets and Android bridge code"
JAVA_DIR=android/app/src/main/java/com/javediqbal/shianamaz
mkdir -p "$JAVA_DIR"
cp "$SRC/native/java/"*.java "$JAVA_DIR/"
mkdir -p android/app/src/main/assets
cp "$SRC/native/quotes.json" android/app/src/main/assets/quotes.json

echo "== Permissions and portrait mode"
MAN=android/app/src/main/AndroidManifest.xml
python3 - "$MAN" <<'PY'
import sys
p = sys.argv[1]
m = open(p, encoding="utf-8").read()
perms = ["POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "USE_EXACT_ALARM", "RECEIVE_BOOT_COMPLETED",
         "VIBRATE", "ACCESS_COARSE_LOCATION", "ACCESS_FINE_LOCATION", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"]
block = "".join('<uses-permission android:name="android.permission.%s" />\n    ' % x for x in perms)
m = m.replace("<application", block + "<application", 1)
m = m.replace('android:name=".MainActivity"', 'android:name=".MainActivity"\n            android:screenOrientation="portrait"', 1)
widgets = """
        <receiver android:name=".NextPrayerWidget" android:exported="false" android:label="@string/wg_next_name">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_next_info" />
        </receiver>
        <receiver android:name=".DayTimesWidget" android:exported="false" android:label="@string/wg_day_name">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_day_info" />
        </receiver>
        <receiver android:name=".QuoteWidget" android:exported="false" android:label="@string/wg_quote_name">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_quote_info" />
        </receiver>
        <receiver android:name=".WidgetRefreshReceiver" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.intent.action.DATE_CHANGED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>
    </application>"""
m = m.replace("</application>", widgets.lstrip(), 1)
# new icon names, so launchers and the widget list cannot keep showing an old cached icon
m = m.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_app"')
m = m.replace('android:roundIcon="@mipmap/ic_launcher_round"', 'android:roundIcon="@mipmap/ic_app_round"')
for w in ('NextPrayerWidget', 'DayTimesWidget', 'QuoteWidget'):
    m = m.replace('<receiver android:name=".%s"' % w, '<receiver android:name=".%s" android:icon="@mipmap/ic_app"' % w, 1)
open(p, "w", encoding="utf-8").write(m)
PY

echo "== Signing and version"
cp "$SRC/release.jks" android/app/release.jks
cat >> android/app/build.gradle <<GRADLE

android {
    defaultConfig {
        versionCode((System.getenv("BUILD_NUMBER") ?: System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInteger())
        versionName("1.0." + (System.getenv("BUILD_NUMBER") ?: System.getenv("GITHUB_RUN_NUMBER") ?: "1"))
    }
    signingConfigs {
        release {
            storeFile file("release.jks")
            storePassword "$KS_PASS"
            keyAlias "shianamaz"
            keyPassword "$KS_PASS"
        }
    }
    buildTypes { release { signingConfig signingConfigs.release; minifyEnabled false } }
    lint { abortOnError false; checkReleaseBuilds false }
}
GRADLE

npx cap sync android

echo "== Building APK"
cd android && chmod +x gradlew && ./gradlew assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk "$OUT/ShiaNamaz.apk"
echo "== Done: ShiaNamaz.apk"
